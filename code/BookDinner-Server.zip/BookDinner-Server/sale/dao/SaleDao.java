package dao;

import java.util.ArrayList;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.dialect.identity.CUBRIDIdentityColumnSupport;
import org.hibernate.query.Query;
import org.omg.CORBA.PUBLIC_MEMBER;

import bean.CuisineBean;
import bean.FoodBean;
import bean.OrderRecordBean;
import bean.UserBean;
import net.sf.json.JSONArray;

public class SaleDao {
	
	public static ArrayList<FoodBean> getFoodList(Integer cuisine_id){
		String sql="select bean from  FoodBean bean where bean.cuisineId="+cuisine_id+"and bean.isPublished=1";
		SessionFactory sessionFactory = hibernateStartPrepare.getSessionFactory();
		Session session = sessionFactory.openSession();
		Transaction transaction = session.beginTransaction();
		Query query = session.createQuery(sql);
		ArrayList<FoodBean> list =  (ArrayList<FoodBean>) query.list();
		try {
			transaction.commit();
		} catch (Exception e) {
			System.out.println(e);
			transaction.rollback();
			// TODO: handle exception
		} finally {
			session.close();
			
		}
		return list;
		
		
	}
	
	
	public static ArrayList<FoodBean> getHotSaleList(){
		String sql="select bean from FoodBean as bean where bean.hotSale=1 and bean.isPublished=1";
		SessionFactory sessionFactory = hibernateStartPrepare.getSessionFactory();
		Session session = sessionFactory.openSession();
		Transaction transaction = session.beginTransaction();
		Query query = session.createQuery(sql);
		ArrayList<FoodBean> list =  (ArrayList<FoodBean>) query.list();
		try {
			transaction.commit();
		} catch (Exception e) {
			System.out.println(e);
			transaction.rollback();
			// TODO: handle exception
		} finally {
			session.close();
		}
		return list;
		
		
	}
	
	
	public static ArrayList<CuisineBean> getCuisineList(){
		
		String sql="select bean from CuisineBean as bean ";
		SessionFactory sessionFactory = hibernateStartPrepare.getSessionFactory();
		Session session = sessionFactory.openSession();
		Transaction transaction = session.beginTransaction();
		Query query = session.createQuery(sql);
		ArrayList<CuisineBean> list =  (ArrayList<CuisineBean>) query.list();
		try {
			transaction.commit();
		} catch (Exception e) {
			System.out.println(e);
			transaction.rollback();
			// TODO: handle exception
		} finally {
			session.close();
		}
		return list;
		
	}
	
	
	public static int saveOrderRecord(OrderRecordBean bean){
		SessionFactory sessionFactory = hibernateStartPrepare.getSessionFactory();
		Session session = sessionFactory.openSession();
		Transaction transaction = session.beginTransaction();
		try {
			
			session.save(bean);
			transaction.commit();
		
		} catch (Exception e) {
			System.out.println(e);
			transaction.rollback();
			// TODO: handle exception
		} finally {
			session.close();
		}
		return 0;
	}
	
	public static  ArrayList<OrderRecordBean> getOrderRecord(String id){
		String sql="select bean from OrderRecordBean as bean where userId="+id+"group by number ORDER BY create_time DESC";
		SessionFactory sessionFactory = hibernateStartPrepare.getSessionFactory();
		Session session = sessionFactory.openSession();
		Transaction transaction = session.beginTransaction();
		Query query = session.createQuery(sql);
		ArrayList<OrderRecordBean> list =  (ArrayList<OrderRecordBean>) query.list();
		try {
			transaction.commit();
		} catch (Exception e) {
			System.out.println(e);
			transaction.rollback();
			// TODO: handle exception
		} finally {
			session.close();
		}
		return list;
	}
	
	
	public static JSONArray getOrderFood(String number){
		String sql="select foodBean,orderBean.count from OrderRecordBean as orderBean, FoodBean as foodBean"
				+ " where orderBean.number="+number+"and orderBean.foodId=foodBean.id";
		SessionFactory sessionFactory = hibernateStartPrepare.getSessionFactory();
		Session session = sessionFactory.openSession();
		Transaction transaction = session.beginTransaction();
		Query query = session.createQuery(sql);
		JSONArray jsonArray=JSONArray.fromObject((ArrayList<FoodBean>) query.list())  ;
		try {
			transaction.commit();
		} catch (Exception e) {
			System.out.println(e);
			transaction.rollback();
			// TODO: handle exception
		} finally {
			session.close();
		}
		
		return jsonArray;
	
		
	}
	
	
	public static int delOrder(String number){
		
		String sql="delete from OrderRecordBean where number="+number;
		SessionFactory sessionFactory = hibernateStartPrepare.getSessionFactory();
		Session session = sessionFactory.openSession();
		Transaction transaction = session.beginTransaction();
		Query query = session.createQuery(sql);
		query.executeUpdate() ;
	
		try {
			transaction.commit();
		} catch (Exception e) {
			System.out.println(e);
			transaction.rollback();
			// TODO: handle exception
		} finally {
			session.close();
		}
		
		return 0;
	}
	
	public static CuisineBean addCuisine(String name){
		CuisineBean cuisineBean=new CuisineBean();
		cuisineBean.setCuisineName(name);
		cuisineBean.setAbs("");
		cuisineBean.setImgUrl("");
		String sql_2="select bean from CuisineBean bean where cuisine_name="+"'"+name+"'";
		SessionFactory sessionFactory = hibernateStartPrepare.getSessionFactory();
		Session session = sessionFactory.openSession();
		Transaction transaction = session.beginTransaction();
		Query query = session.createQuery(sql_2);
		if(query.list().size()==0){
			session.save(cuisineBean);
			Query query_2 = session.createQuery(sql_2);
			cuisineBean=(CuisineBean) query_2.uniqueResult();
			try {
				transaction.commit();
			} catch (Exception e) {
				System.out.println(e);
				transaction.rollback();
				// TODO: handle exception
			} finally {
				session.close();
			}
			return cuisineBean;
			
		}else{
			try {
				transaction.commit();
			} catch (Exception e) {
				System.out.println(e);
				transaction.rollback();
				// TODO: handle exception
			} finally {
				session.close();
			}
			return null;
		}

		
	}
	
	public static void renameCuisine(CuisineBean cuisineBean){
		
		SessionFactory sessionFactory = hibernateStartPrepare.getSessionFactory();
		Session session = sessionFactory.openSession();
		Transaction transaction = session.beginTransaction();
	
		try {
			session.update(cuisineBean);
			transaction.commit();
		} catch (Exception e) {
			System.out.println(e);
			transaction.rollback();
			// TODO: handle exception
		} finally {
			session.close();
		}
	}
	
	public static void removeCuisine(Integer id){
		String sql="delete from CuisineBean  where id="+id;
		SessionFactory sessionFactory = hibernateStartPrepare.getSessionFactory();
		Session session = sessionFactory.openSession();
		Transaction transaction = session.beginTransaction();
		Query query = session.createQuery(sql);
		query.executeUpdate() ;
	
		try {
			transaction.commit();
		} catch (Exception e) {
			System.out.println(e);
			transaction.rollback();
			// TODO: handle exception
		} finally {
			session.close();
		}
		
	}
	
	public static void updateFood(FoodBean foodBean){
		SessionFactory sessionFactory = hibernateStartPrepare.getSessionFactory();
		Session session = sessionFactory.openSession();
		Transaction transaction = session.beginTransaction();
	
		try {
			session.update(foodBean);
			transaction.commit();
		} catch (Exception e) {
			System.out.println(e);
			transaction.rollback();
			// TODO: handle exception
		} finally {
			session.close();
		}
	}
	
	public static void delFood(Integer id){
		String sql="delete from FoodBean  where id="+id;
		SessionFactory sessionFactory = hibernateStartPrepare.getSessionFactory();
		Session session = sessionFactory.openSession();
		Transaction transaction = session.beginTransaction();
		Query query = session.createQuery(sql);
		query.executeUpdate() ;
	
		try {
			transaction.commit();
		} catch (Exception e) {
			System.out.println(e);
			transaction.rollback();
			// TODO: handle exception
		} finally {
			session.close();
		}
	}
	
	public static FoodBean addFood(FoodBean foodBean){
		FoodBean foodBean2 = null;
		System.out.println("foodNmae"+foodBean.getFoodName());
		String sql_2="select bean from FoodBean bean where  foodName="+"'"+foodBean.getFoodName()+"'";
		SessionFactory sessionFactory = hibernateStartPrepare.getSessionFactory();
		Session session = sessionFactory.openSession();
		Transaction transaction = session.beginTransaction();
	
		try {
			session.save(foodBean);
		
			
			transaction.commit();
		} catch (Exception e) {
			System.out.println(e);
			transaction.rollback();
			// TODO: handle exception
		} finally {
			session.close();
		}
		System.out.println(foodBean.getId());
		return foodBean;
	}
	
	public static ArrayList<OrderRecordBean> getAllOrderRecord(){
		String sql="select bean from  OrderRecordBean bean group by number";
		SessionFactory sessionFactory = hibernateStartPrepare.getSessionFactory();
		Session session = sessionFactory.openSession();
		Transaction transaction = session.beginTransaction();
		Query query = session.createQuery(sql);
		ArrayList<OrderRecordBean> list =  (ArrayList<OrderRecordBean>) query.list();
		try {
			transaction.commit();
		} catch (Exception e) {
			System.out.println(e);
			transaction.rollback();
			// TODO: handle exception
		} finally {
			session.close();
			
		}
		return list;
		
	}
}
