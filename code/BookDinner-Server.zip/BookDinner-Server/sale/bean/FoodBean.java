package bean;

public class FoodBean {
	
	private int id;
	private int hotSale;
	private String foodName;
	private String abs;
	private int sale;
	private float price;
	private int isPublished;
	private int cuisineId;
	private String imgUrl;
	/**
	 * @return the id
	 */
	public int getId() {
		return id;
	}
	/**
	 * @param id the id to set
	 */
	public void setId(int id) {
		this.id = id;
	}
	/**
	 * @return the hotSale
	 */
	public int getHotSale() {
		return hotSale;
	}
	/**
	 * @param hotSale the hotSale to set
	 */
	public void setHotSale(int hotSale) {
		this.hotSale = hotSale;
	}
	/**
	 * @return the foodName
	 */
	public String getFoodName() {
		return foodName;
	}
	/**
	 * @param foodName the foodName to set
	 */
	public void setFoodName(String foodName) {
		this.foodName = foodName;
	}
	/**
	 * @return the abs
	 */
	public String getAbs() {
		return abs;
	}
	/**
	 * @param abs the abs to set
	 */
	public void setAbs(String abs) {
		this.abs = abs;
	}
	/**
	 * @return the sale
	 */
	public int getSale() {
		return sale;
	}
	/**
	 * @param sale the sale to set
	 */
	public void setSale(int sale) {
		this.sale = sale;
	}
	/**
	 * @return the price
	 */
	public float getPrice() {
		return price;
	}
	/**
	 * @param price the price to set
	 */
	public void setPrice(float price) {
		this.price = price;
	}
	/**
	 * @return the isPublished
	 */
	public int getIsPublished() {
		return isPublished;
	}
	/**
	 * @param isPublished the isPublished to set
	 */
	public void setIsPublished(int isPublished) {
		this.isPublished = isPublished;
	}
	/**
	 * @return the cuisineDi
	 */
	/**
	 * @return the cuisineId
	 */
	public int getCuisineId() {
		return cuisineId;
	}
	/**
	 * @param cuisineId the cuisineId to set
	 */
	public void setCuisineId(int cuisineId) {
		this.cuisineId = cuisineId;
	}
	/**
	 * @return the imgUrl
	 */
	public String getImgUrl() {
		return imgUrl;
	}
	/**
	 * @param imgUrl the imgUrl to set
	 */
	public void setImgUrl(String imgUrl) {
		this.imgUrl = imgUrl;
	}

	
	
}
