package bean;

public class CuisineBean {
	private int id;
	private String cuisineName;
	private String imgUrl;
	private String abs;
	/**
	 * @return the id
	 */
	public int getId() {
		return id;
	}
	/**
	 * @param id the id to set
	 */
	public void setId(int id) {
		this.id = id;
	}
	/**
	 * @return the cuisineName
	 */
	public String getCuisineName() {
		return cuisineName;
	}
	/**
	 * @param cuisineName the cuisineName to set
	 */
	public void setCuisineName(String cuisineName) {
		this.cuisineName = cuisineName;
	}
	/**
	 * @return the imgUrl
	 */
	public String getImgUrl() {
		return imgUrl;
	}
	/**
	 * @param imgUrl the imgUrl to set
	 */
	public void setImgUrl(String imgUrl) {
		this.imgUrl = imgUrl;
	}
	/**
	 * @return the abs
	 */
	public String getAbs() {
		return abs;
	}
	/**
	 * @param abs the abs to set
	 */
	public void setAbs(String abs) {
		this.abs = abs;
	}
	
	
}
