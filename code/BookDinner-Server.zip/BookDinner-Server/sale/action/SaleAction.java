package action;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.StringEscapeUtils;
import org.apache.logging.log4j.message.StringFormattedMessage;
import org.apache.struts2.ServletActionContext;
import org.hibernate.transform.ResultTransformer;

import com.opensymphony.xwork2.ActionSupport;

import DBUtils.DAOUtils;
import bean.CuisineBean;
import bean.FoodBean;
import bean.OrderRecordBean;
import dao.SaleDao;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

public class SaleAction extends ActionSupport {
	
	private HttpServletRequest request;
	private HttpServletResponse response;
	private HttpSession session = null;
	
	public String getFoodList() throws IOException{
		HttpServletResponse response = ServletActionContext.getResponse();  
		response.setHeader("Access-Control-Allow-Origin", "http://localhost:8081");
		response.setHeader("Access-Control-Allow-Methods", "POST,GET");
		response.setHeader("Access-Control-Allow-Credentials","true");
		response.setHeader("Access-Control-Allow-Headers", "x-requested-with,content-type");
		Integer cuisine_id=Integer.valueOf(ServletActionContext.getRequest().getParameter("cuisine_id"));
		System.out.println("cuisine_id");
		PrintWriter out = DAOUtils.getPrintWriter(ServletActionContext.getResponse());
		ArrayList<FoodBean> list=SaleDao.getFoodList(cuisine_id);
		if(list == null) {
			out.print(JSONObject.fromObject("{status:-1}"));
		} else{
			out.print(JSONObject.fromObject("{status:1,results:" + JSONArray.fromObject(list) + "}"));
		}
		
		DAOUtils.CloseWirter(out);
		return null;
	}
	
	
	public String getHotSale() throws IOException{
		HttpServletResponse response = ServletActionContext.getResponse();  
		response.setHeader("Access-Control-Allow-Origin", "http://localhost:8081");
		response.setHeader("Access-Control-Allow-Methods", "POST,GET");
		response.setHeader("Access-Control-Allow-Credentials","true");
		response.setHeader("Access-Control-Allow-Headers", "x-requested-with,content-type");
		PrintWriter out = DAOUtils.getPrintWriter(ServletActionContext.getResponse());
		ArrayList<FoodBean> list=SaleDao.getHotSaleList();
		if(list == null) {
			out.print(JSONObject.fromObject("{status:-1}"));
		} else{
			out.print(JSONObject.fromObject("{status:1,results:" + JSONArray.fromObject(list) + "}"));
		}
		
		DAOUtils.CloseWirter(out);
		return null;
		
	}
	
	public String getCuisineList() throws IOException{
		HttpServletResponse response = ServletActionContext.getResponse();  
		response.setHeader("Access-Control-Allow-Origin", "http://localhost:8081");
		response.setHeader("Access-Control-Allow-Methods", "POST,GET");
		response.setHeader("Access-Control-Allow-Credentials","true");
		response.setHeader("Access-Control-Allow-Headers", "x-requested-with,content-type");
		PrintWriter out = DAOUtils.getPrintWriter(ServletActionContext.getResponse());
		ArrayList<CuisineBean> list=SaleDao.getCuisineList();
		if(list == null) {
			out.print(JSONObject.fromObject("{status:-1}"));
		} else{
			out.print(JSONObject.fromObject("{status:1,results:" + JSONArray.fromObject(list) + "}"));
		}
		
		DAOUtils.CloseWirter(out);
		return null;
	}
	
	
	public String saveOrderRecord() throws IOException, ParseException{
		HttpServletResponse response = ServletActionContext.getResponse();  
		request=ServletActionContext.getRequest();
		response.setHeader("Access-Control-Allow-Origin", "http://localhost:8081");
		response.setHeader("Access-Control-Allow-Methods", "POST,GET");
		response.setHeader("Access-Control-Allow-Credentials","true");
		response.setHeader("Access-Control-Allow-Headers", "x-requested-with,content-type");
		PrintWriter out = DAOUtils.getPrintWriter(ServletActionContext.getResponse());
		String addr=request.getParameter("addr");
		String number=request.getParameter("number");
		float count_price=Float.parseFloat(request.getParameter("count_price"));
		Integer userId=Integer.valueOf(request.getParameter("userId"));
		String time=request.getParameter("create_time");
		System.out.println("time"+time);
		String buy=(String)request.getParameter("buy_bus");
		JSONArray buy_bus=JSONArray.fromObject(buy);
		System.out.println(buy);
		System.out.println( buy_bus.toString());
		if(buy_bus.size()>0){
			for (int i = 0; i <buy_bus.size(); i++) {
				System.out.println(buy_bus.getJSONObject(i));
				OrderRecordBean  bean=new OrderRecordBean();
				bean.setAddr(addr);
				bean.setCreateTime(new Date());
				bean.setFoodId(buy_bus.getJSONObject(i).getInt("id"));
				bean.setNumber(number);
				bean.setStatus("������");
				bean.setUserId(userId);
				bean.setCountPrice(count_price);
				bean.setCount(buy_bus.getJSONObject(i).getInt("count"));
				if(buy_bus.size()==1){
					bean.setAbs(buy_bus.getJSONObject(i).getString("foodName"));
				}else{
					bean.setAbs(buy_bus.getJSONObject(0).getString("foodName")+"��");
				}
				
				SaleDao.saveOrderRecord(bean);
				
			}
		}
		out.print(JSONObject.fromObject("{status:1}"));
		DAOUtils.CloseWirter(out);
		return null;
	}
	
	public String getOrderRecord() throws IOException{
		HttpServletResponse response = ServletActionContext.getResponse();  
		response.setHeader("Access-Control-Allow-Origin", "http://localhost:8081");
		response.setHeader("Access-Control-Allow-Methods", "POST,GET");
		response.setHeader("Access-Control-Allow-Credentials","true");
		response.setHeader("Access-Control-Allow-Headers", "x-requested-with,content-type");
		PrintWriter out = DAOUtils.getPrintWriter(ServletActionContext.getResponse());
		request=ServletActionContext.getRequest();
		String  id=request.getParameter("userId");
		ArrayList<OrderRecordBean> list=SaleDao.getOrderRecord(id);
		if(list == null) {
			out.print(JSONObject.fromObject("{status:-1}"));
		} else{
			out.print(JSONObject.fromObject("{status:1,results:" + JSONArray.fromObject(list) + "}"));
		}
		
		DAOUtils.CloseWirter(out);
		return null;
	}
	
	
	public String getOrderFood() throws IOException{
		HttpServletResponse response = ServletActionContext.getResponse();  
		response.setHeader("Access-Control-Allow-Origin", "http://localhost:8081");
		response.setHeader("Access-Control-Allow-Methods", "POST,GET");
		response.setHeader("Access-Control-Allow-Credentials","true");
		response.setHeader("Access-Control-Allow-Headers", "x-requested-with,content-type");

		PrintWriter out = DAOUtils.getPrintWriter(ServletActionContext.getResponse());
		request=ServletActionContext.getRequest();
		String  id=request.getParameter("number");
		System.out.println("number"+id);
		JSONArray list=SaleDao.getOrderFood(id);
		if(list == null) {
			out.print(JSONObject.fromObject("{status:-1}"));
		} else{
			out.print(JSONObject.fromObject("{status:1,results:" + list + "}"));
		}
		
		DAOUtils.CloseWirter(out);
		return null;
	}
	
	
	public String delOrder() throws IOException{
		HttpServletResponse response = ServletActionContext.getResponse();  
		response.setHeader("Access-Control-Allow-Origin", "http://localhost:8081");
		response.setHeader("Access-Control-Allow-Methods", "POST,GET");
		response.setHeader("Access-Control-Allow-Credentials","true");
		response.setHeader("Access-Control-Allow-Headers", "x-requested-with,content-type");

		PrintWriter out = DAOUtils.getPrintWriter(ServletActionContext.getResponse());
		request=ServletActionContext.getRequest();
		String  id=request.getParameter("number");
		System.out.println("number"+id);
	    SaleDao.delOrder(id);
	    out.print(JSONObject.fromObject("{status:1}"));	
		DAOUtils.CloseWirter(out);
		return null;
	}
	
	
    public String addCuisine() throws IOException{
    	HttpServletResponse response = ServletActionContext.getResponse();  
		response.setHeader("Access-Control-Allow-Origin", "http://localhost:8081");
		response.setHeader("Access-Control-Allow-Methods", "POST,GET");
		response.setHeader("Access-Control-Allow-Credentials","true");
		response.setHeader("Access-Control-Allow-Headers", "x-requested-with,content-type");
		PrintWriter out = DAOUtils.getPrintWriter(ServletActionContext.getResponse());
		request=ServletActionContext.getRequest();
		String  id=request.getParameter("number");
		System.out.println("number"+id);
	    CuisineBean cuisineBean=SaleDao.addCuisine(id);
		if(cuisineBean == null) {
			out.print(JSONObject.fromObject("{status:-1}"));
		} else{
			out.print(JSONObject.fromObject("{status:1,results:" + JSONObject.fromObject(cuisineBean) + "}"));
		}
		DAOUtils.CloseWirter(out);
		return null;
	}
    
    
    public String renameCuisine() throws IOException{
    	HttpServletResponse response = ServletActionContext.getResponse();  
		response.setHeader("Access-Control-Allow-Origin", "http://localhost:8081");
		response.setHeader("Access-Control-Allow-Methods", "POST,GET");
		response.setHeader("Access-Control-Allow-Credentials","true");
		response.setHeader("Access-Control-Allow-Headers", "x-requested-with,content-type");
		PrintWriter out = DAOUtils.getPrintWriter(ServletActionContext.getResponse());
		request=ServletActionContext.getRequest();
		Integer  id=Integer.valueOf(request.getParameter("id"));
		String cuisine_name=request.getParameter("cuisine_name");
		String abs=request.getParameter("abs");
		String img_url=request.getParameter("img_url");
		CuisineBean cuisineBean=new CuisineBean();
		cuisineBean.setAbs(abs);
		cuisineBean.setImgUrl(img_url);
		cuisineBean.setCuisineName(cuisine_name);
		cuisineBean.setId(id);
	    SaleDao.renameCuisine(cuisineBean);
	
			out.print(JSONObject.fromObject("{status:1,results:1}"));
	
		DAOUtils.CloseWirter(out);
    	return null;
    }
    
    public String removeCuisine() throws IOException{
    	HttpServletResponse response = ServletActionContext.getResponse();  
		response.setHeader("Access-Control-Allow-Origin", "http://localhost:8081");
		response.setHeader("Access-Control-Allow-Methods", "POST,GET");
		response.setHeader("Access-Control-Allow-Credentials","true");
		response.setHeader("Access-Control-Allow-Headers", "x-requested-with,content-type");
		PrintWriter out = DAOUtils.getPrintWriter(ServletActionContext.getResponse());
		request=ServletActionContext.getRequest();
		Integer  id=Integer.valueOf(request.getParameter("id"));
		
	    SaleDao.removeCuisine(id);
	
			out.print(JSONObject.fromObject("{status:1,results:1}"));
	
		DAOUtils.CloseWirter(out);
    	return null;
    }
    
    public String updateFood() throws IOException{
      	HttpServletResponse response = ServletActionContext.getResponse();  
    		response.setHeader("Access-Control-Allow-Origin", "http://localhost:8081");
    		response.setHeader("Access-Control-Allow-Methods", "POST,GET");
    		response.setHeader("Access-Control-Allow-Credentials","true");
    		response.setHeader("Access-Control-Allow-Headers", "x-requested-with,content-type");
    		PrintWriter out = DAOUtils.getPrintWriter(ServletActionContext.getResponse());
    		request=ServletActionContext.getRequest();
    		Integer  id=Integer.valueOf(request.getParameter("id"));
    		String cuisine_name=request.getParameter("cuisine_name");
    		String abs=request.getParameter("abs");
    		String img_url=request.getParameter("img_url");
    		FoodBean foodBean=new FoodBean();
    		foodBean.setAbs(request.getParameter("abs"));
    		foodBean.setCuisineId(Integer.valueOf(request.getParameter("cuisineId")));
    		foodBean.setFoodName(request.getParameter("foodName"));
    		foodBean.setHotSale(Integer.valueOf(request.getParameter("hotSale")));
    		foodBean.setId(Integer.valueOf(request.getParameter("id")));
    		foodBean.setImgUrl(request.getParameter("imgUrl"));
    		foodBean.setIsPublished(Integer.valueOf(request.getParameter("isPublished")));
    		foodBean.setPrice(Float.parseFloat(request.getParameter("price")));
    		foodBean.setSale(Integer.valueOf(request.getParameter("sale")));
    	    SaleDao.updateFood(foodBean);
    	
    			out.print(JSONObject.fromObject("{status:1,results:1}"));
    	
    		DAOUtils.CloseWirter(out);
    	return null;
    }
    
    
    public String delFood() throws IOException{
    	HttpServletResponse response = ServletActionContext.getResponse();  
    	response.setHeader("Access-Control-Allow-Origin", "http://localhost:8081");
		response.setHeader("Access-Control-Allow-Methods", "POST,GET");
		response.setHeader("Access-Control-Allow-Credentials","true");
		response.setHeader("Access-Control-Allow-Headers", "x-requested-with,content-type");
		PrintWriter out = DAOUtils.getPrintWriter(ServletActionContext.getResponse());
		request=ServletActionContext.getRequest();
		Integer  id=Integer.valueOf(request.getParameter("id"));
		
	    SaleDao.delFood(id);
	
			out.print(JSONObject.fromObject("{status:1,results:1}"));
	
		DAOUtils.CloseWirter(out);
    	
		return null;
    	
    }
    
    
    public  String addFood() throws IOException{
      	HttpServletResponse response = ServletActionContext.getResponse();  
      	response.setHeader("Access-Control-Allow-Origin", "http://localhost:8081");
		response.setHeader("Access-Control-Allow-Methods", "POST,GET");
		response.setHeader("Access-Control-Allow-Credentials","true");
		response.setHeader("Access-Control-Allow-Headers", "x-requested-with,content-type");
				PrintWriter out = DAOUtils.getPrintWriter(ServletActionContext.getResponse());
    		HttpServletRequest request=ServletActionContext.getRequest();
    		String cuisine_name=request.getParameter("cuisine_name");
    		String abs=request.getParameter("abs");
    		String img_url=request.getParameter("img_url");
    		FoodBean foodBean=new FoodBean();
    		foodBean.setAbs(request.getParameter("abs"));
    		foodBean.setCuisineId(Integer.valueOf(request.getParameter("cuisineId")));
    		foodBean.setFoodName(request.getParameter("foodName"));
    		foodBean.setHotSale(Integer.valueOf(request.getParameter("hotSale")));
    		foodBean.setImgUrl(request.getParameter("imgUrl"));
    		foodBean.setIsPublished(Integer.valueOf(request.getParameter("isPublished")));
    		foodBean.setPrice(Float.parseFloat(request.getParameter("price")));
    		foodBean.setSale(Integer.valueOf(request.getParameter("sale")));
    	    FoodBean foodBean2=SaleDao.addFood(foodBean);
    	    if(foodBean2==null){
    	    	out.print(JSONObject.fromObject("{status:1,results:-1}"));
    	    }else{
    	    	out.print(JSONObject.fromObject("{status:1,results:" + JSONObject.fromObject(foodBean) + "}"));
    	    	
    	    }
    			
    	
    		DAOUtils.CloseWirter(out);
			return null;
    }
	
    
    
    public String getAllOrderRecord() throws IOException{
    	HttpServletResponse response = ServletActionContext.getResponse();  
		response.setHeader("Access-Control-Allow-Origin", "http://localhost:8081");
		response.setHeader("Access-Control-Allow-Methods", "POST,GET");
		response.setHeader("Access-Control-Allow-Credentials","true");
		response.setHeader("Access-Control-Allow-Headers", "x-requested-with,content-type");
		PrintWriter out = DAOUtils.getPrintWriter(ServletActionContext.getResponse());
		request=ServletActionContext.getRequest();
		String  id=request.getParameter("number");
		System.out.println("number"+id);
	    ArrayList<OrderRecordBean> orderRecordBeans=SaleDao.getAllOrderRecord();
		if(orderRecordBeans == null) {
			out.print(JSONObject.fromObject("{status:-1}"));
		} else{
			out.print(JSONObject.fromObject("{status:1,results:" + JSONArray.fromObject(orderRecordBeans) + "}"));
		}
		DAOUtils.CloseWirter(out);
		return null;
    	
    }
	
	

}
