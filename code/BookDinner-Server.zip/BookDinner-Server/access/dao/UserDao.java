package dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import bean.UserBean;

public class UserDao {
	
	
	public static UserBean getAdminUser(UserBean userBean){
		System.out.println("type"+userBean.getType());
		String sql="select user from UserBean as user where phone=? and user.type=1";
		SessionFactory sessionFactory = hibernateStartPrepare.getSessionFactory();
		Session session = sessionFactory.openSession();
		Transaction transaction = session.beginTransaction();
		Query query = session.createQuery(sql);
		System.out.println("do 1");
		query.setParameter(0, userBean.getPhone());
		System.out.println("do 2");
		UserBean user = (UserBean) query.uniqueResult();
		try {
			transaction.commit();
		} catch (Exception e) {
			System.out.println(e);
			transaction.rollback();
			// TODO: handle exception
		} finally {
			session.close();
		}
		if(user==null){
			System.out.println("return -1");
			return null;
			
		}else if(user.getPassword().equals(userBean.getPassword())&&user.getPhone().equals(userBean.getPhone())){
			System.out.println("return user");
			return user;

		}else{
			System.out.println("return 0");
			return null;
		}	
	}
	
	
	public static UserBean getUser(UserBean userBean){
		System.out.println("type"+userBean.getType());
		String sql="select user from UserBean as user where phone=? ";
		SessionFactory sessionFactory = hibernateStartPrepare.getSessionFactory();
		Session session = sessionFactory.openSession();
		Transaction transaction = session.beginTransaction();
		Query query = session.createQuery(sql);
		System.out.println("do 1");
		query.setParameter(0, userBean.getPhone());
		System.out.println("do 2");
		UserBean user = (UserBean) query.uniqueResult();
		try {
			transaction.commit();
		} catch (Exception e) {
			System.out.println(e);
			transaction.rollback();
			// TODO: handle exception
		} finally {
			session.close();
		}
		if(user==null){
			System.out.println("return -1");
			return null;
			
		}else if(user.getPassword().equals(userBean.getPassword())&&user.getPhone().equals(userBean.getPhone())){
			System.out.println("return user");
			return user;

		}else{
			System.out.println("return 0");
			return null;
		}	
	}
	
	public static void  saveUser(UserBean userBean){
		SessionFactory sessionFactory = hibernateStartPrepare.getSessionFactory();
		Session session = sessionFactory.openSession();
		Transaction transaction = session.beginTransaction();
		try {
			session.save(userBean);
			transaction.commit();
		} catch (Exception e) {
			System.out.println(e);
			transaction.rollback();
			// TODO: handle exception
		} finally {
			session.close();
		}
	}
}
