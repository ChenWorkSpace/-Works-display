package action;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts2.ServletActionContext;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.transform.ResultTransformer;

import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ModelDriven;

import DBUtils.DAOUtils;
import bean.UserBean;
import dao.UserDao;
import dao.hibernateStartPrepare;
import javassist.expr.NewArray;
import net.sf.json.JSONObject;

public class UserAction extends ActionSupport implements ModelDriven<UserBean> {

	private static final long serialVersionUID = 1L;
	private HttpServletRequest request;
	private HttpServletResponse response;
	private HttpSession session = null;
	private JSONObject userContent;
	private UserBean userBean = new UserBean();

	/**
	 * -1����δ�ҵ����û� 0�����˻����������  
	 * @return
	 * @throws IOException
	 */
	public String logIn() throws IOException {

		userContent = new JSONObject();
		HttpServletResponse response = ServletActionContext.getResponse();  
		response.setHeader("Access-Control-Allow-Origin", "http://localhost:8081");
		response.setHeader("Access-Control-Allow-Methods", "POST,GET");
		response.setHeader("Access-Control-Allow-Credentials","true");
		response.setHeader("Access-Control-Allow-Headers", "x-requested-with,content-type");
		System.out.println("Get into Login");
		request = ServletActionContext.getRequest();
		PrintWriter out = DAOUtils.getPrintWriter(ServletActionContext.getResponse());
		response = ServletActionContext.getResponse();
		request.setCharacterEncoding("utf-8");
		session = ServletActionContext.getRequest().getSession();
		System.out.println(userBean.getUsername());
		userBean = UserDao.getUser(userBean);
		if (userBean == null) {
			out.print(JSONObject.fromObject("{status:0}"));
		} else{
			session.setAttribute("user", userBean);
			out.print(JSONObject.fromObject("{status:1,results:" + JSONObject.fromObject(userBean) + "}"));
		}
		DAOUtils.CloseWirter(out);
		return null;
	}
	
	
	
	public String logOut() throws IOException {
		PrintWriter out = DAOUtils.getPrintWriter(ServletActionContext.getResponse());
		HttpServletResponse response = ServletActionContext.getResponse();  
		response.setHeader("Access-Control-Allow-Origin", "http://localhost:8081");
		response.setHeader("Access-Control-Allow-Methods", "POST,GET");
		response.setHeader("Access-Control-Allow-Credentials","true");
		response.setHeader("Access-Control-Allow-Headers", "x-requested-with,content-type");
		session = ServletActionContext.getRequest().getSession();
		session.setAttribute("user", null);
		out.print(JSONObject.fromObject("{status:1}"));
		DAOUtils.CloseWirter(out);
		return null;
	}

	public String register() throws IOException {
		userContent = new JSONObject();
		HttpServletResponse response = ServletActionContext.getResponse();  
		response.setHeader("Access-Control-Allow-Origin", "http://localhost:8081");
		response.setHeader("Access-Control-Allow-Methods", "POST,GET");
		response.setHeader("Access-Control-Allow-Credentials","true");
		response.setHeader("Access-Control-Allow-Headers", "x-requested-with,content-type");
		System.out.println("Get into Login");
		request = ServletActionContext.getRequest();
		PrintWriter out = DAOUtils.getPrintWriter(ServletActionContext.getResponse());
		response = ServletActionContext.getResponse();
		request.setCharacterEncoding("utf-8");
		session = ServletActionContext.getRequest().getSession();
		System.out.println(userBean.getUsername());
		UserBean ub = UserDao.getUser(userBean);
		System.out.println("userBean"+userBean);
		if (ub == null) {
			UserDao.saveUser(userBean);
			out.print(JSONObject.fromObject("{status:1}"));
		} else{
			out.print(JSONObject.fromObject("{status:0}"));
		}
		DAOUtils.CloseWirter(out);
		return null;
	}

	public String checkStatus() throws IOException {
		
		session = ServletActionContext.getRequest().getSession();
		userBean=(UserBean) session.getAttribute("user");
		HttpServletResponse response = ServletActionContext.getResponse();  
		response.setHeader("Access-Control-Allow-Origin", "http://localhost:8081");
		response.setHeader("Access-Control-Allow-Methods", "POST,GET");
		response.setHeader("Access-Control-Allow-Credentials","true");
		response.setHeader("Access-Control-Allow-Headers", "x-requested-with,content-type");
		PrintWriter out = DAOUtils.getPrintWriter(ServletActionContext.getResponse());
		if(userBean!=null){
			System.out.println("have user");
			out.print(JSONObject.fromObject("{status:1,results:" + JSONObject.fromObject(userBean) + "}"));
		}else{
			System.out.println("user not have");
			out.print(JSONObject.fromObject("{status:-1}"));
		}
		
		DAOUtils.CloseWirter(out);
		return null;
	}
	
	public String adminLogin() throws IOException{
		userContent = new JSONObject();
		HttpServletResponse response = ServletActionContext.getResponse();  
		response.setHeader("Access-Control-Allow-Origin", "http://localhost:8081");
		response.setHeader("Access-Control-Allow-Methods", "POST,GET");
		response.setHeader("Access-Control-Allow-Credentials","true");
		response.setHeader("Access-Control-Allow-Headers", "x-requested-with,content-type");
		request = ServletActionContext.getRequest();
		PrintWriter out = DAOUtils.getPrintWriter(ServletActionContext.getResponse());
		response = ServletActionContext.getResponse();
		request.setCharacterEncoding("utf-8");
		session = ServletActionContext.getRequest().getSession();
		System.out.println(userBean.getUsername());
		userBean = UserDao.getAdminUser(userBean);
		if (userBean == null) {
			out.print(JSONObject.fromObject("{status:0}"));
		} else{
			session.setAttribute("user", userBean);
			out.print(JSONObject.fromObject("{status:1,results:" + JSONObject.fromObject(userBean) + "}"));
		}
		DAOUtils.CloseWirter(out);
		return null;
	}
	
	
	

	public UserBean getModel() {
		// TODO Auto-generated method stub
		return userBean;
	}

}
