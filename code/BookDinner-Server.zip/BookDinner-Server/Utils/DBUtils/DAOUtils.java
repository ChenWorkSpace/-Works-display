package DBUtils;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.http.HttpServletResponse;

import org.apache.struts2.ServletActionContext;

public class DAOUtils {

	
	
	public static  PrintWriter getPrintWriter(HttpServletResponse response ) throws IOException {
		response.setContentType("text/text");
		response.setCharacterEncoding("UTF-8");
		return response.getWriter();
	
	}
	
	public static void CloseWirter(PrintWriter out) {
		if (null != out) {
			out.flush();
			out.close();
		}

}
}
