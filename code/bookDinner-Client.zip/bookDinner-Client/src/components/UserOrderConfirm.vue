<template>
<div class="Details  col-xs-12">

<div class="row header">
  <div class="col-xs-12">

<span  class="el-icon-back back_icon fa-2x" plain style="float:left;margin-left:35px;margin-top:25px;cursor:pointer;"   v-on:click="backPage"></span>
<p style="float:left;font-weight:500;font-size:25px;margin-top:27px;margin-left:15px;cursor:pointer;color:#409eff"  v-on:click="backPage">返回</p>

  <h1 align="center" style="margin-right:200px;align:center">确认订单</h1>
  </div>
<div class="col-xs-6" style="margin-top:40px;">
  <el-steps :space="200" :active="2" finish-status="success" align-center>
    <el-step title="选择商品"></el-step>
    <el-step title="确认订单信息"></el-step>
    <el-step title="成功提交订单"></el-step>
  </el-steps>
</div>

<div class="col-xs-6" style="margin-top:10px;">
<h1 align="content-left" style="font-size:20px;">订单编号：{{number}}</h1>
    <el-button type="delete order " class="is-horizontal is-right" plain style="float:right;margin-right:15px;" v-on:click="backPage">取消此订单</el-button>

</div>


</div>
<div class="row content" style="margin-top:50px;">
  <div class="col-xs-6 content-left" style="height:250px;">
    <el-table align="right"
      :data="tableData4"
      height="300px"
      style="width: 100%;height:300px;">
      <el-table-column
      align="center"
        prop="information"
        label="订单信息"
        style="width: 80%">
      </el-table-column>
    </el-table>

  </div>
  <div class="col-xs-6 conent-right" style="=height:250px">
    <el-table align="center"
      :data="tableData3"
      style="width: 100%;height:300px;" >
      <el-table-column
      align="center"
        prop="foodName"
        label="菜品"
        style="width:80%">
      </el-table-column>
      <el-table-column
      align="center"
        prop="count"
        label="数量"
        style="width:80%">
      </el-table-column>
      <el-table-column
      align="center"
        prop="price"
        label="小计"
        style="width:80%">
      </el-table-column>
    </el-table>
        <router-view/>
  </div>
</div>
<div class="row footer">
  <h1 align="right" style="color:#FF3030;margin-right:15px;"> ￥：{{count_price}}元</h1>
  <el-button type="success" class="is-horizontal is-right" plain style="float:right;margin-right:15px;margin-right:55px;" v-on:click="confirm">确认下单 </el-button>
</div>

</div>


</template>
<script>
export default {
  data() {
    return {
      isClick:true,
      number:'',
      count_price:0,
      tableData3: [

      ],
      tableData4: [
        {information: '下单时间 :'},
        {information: '联系人 :'},
        {information: '联系电话 ：'},
        {information: '地址 :'},
        {information: '备注 :'}
      ]}
},
methods:{
  confirm:function(){
    let thi=this
    if(this.isClick){

      this.jquery.ajax({
        type:"post",
        crossDomain: true,
         xhrFields: {withCredentials: true},
        url:"http://127.0.0.1:8080/BookDinner-Server/sale/saveOrderRecord.action",
        async:true,
        headers: {
           'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8'
        },
        dataType: "json",
        data:{
          'addr':this.$store.getters.getSettlementItem.addr,
          'count_price':this.$store.getters.getSettlementItem.count_price,
          'create_time':this.$store.getters.getSettlementItem.create_time,
          'number':''+this.$store.getters.getSettlementItem.number,
          'userId':this.$store.getters.getSettlementItem.userId,
          'buy_bus':JSON.stringify(this.$store.getters.getSettlementItem.buy_bus)
        },
        success:function(date){
            thi.$router.push({path:"/UserManager/UserOrderManagement/UserOrderDetails"})
            

        }
        })
    }


  },
  backPage(){
    this.$router.go(-1)
  },
  saveOrderRecord:function(){

  }
},
mounted:function(){
  let userData=this.$store.getters.getUser
  let data=this.$store.getters.getSettlementItem
  this.tableData3=data.buy_bus
  this.count_price=data.count_price
  this.number=data.create_time
  let newDate = new Date();
  newDate.setTime(data.create_time);
  this.tableData4[0]['information']=this.tableData4[0]['information']+'  '+newDate.toLocaleString()
  this.tableData4[1]['information']=this.tableData4[1]['information']+'  '+userData.username
  this.tableData4[2]['information']=this.tableData4[2]['information']+'  '+userData.phone
  this.tableData4[3]['information']=this.tableData4[3]['information']+'  '+userData.addr
  this.tableData4[4]['information']=this.tableData4[4]['information']+'  '+'无'
}
}


</script>
<style>

.back_icon{
  height: 40px;
  width: 40px;
   border: solid 1px #409eff;
   border-radius: 50%;
   padding:5px;
   border-color: #409eff;
   color:#409eff;

}

.back_icon:active{
  border-color:#ADD8E6;
  color:#ADD8E6;
   cursor: pointer;
}




  .header{
    height: 150px;

  }
  .content{
    height: 300px;
    background-color: #0000;
  }
  .footer{
    height: 150px;
    background-color: #0000;
  }
  .content-left{
      height: 300px;
    background-color: #0000;
  }
  .content-right{
     height: 300px;
background-color: #0000;
  }
</style>
