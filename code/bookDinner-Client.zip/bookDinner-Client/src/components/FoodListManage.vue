<template lang="html">
  <div>
    <el-button round @click="open3">返回主页</el-button>
  <el-table
    ref="singleTable"
    :data="tableData"
    highlight-current-row
    style="width: 100%"
    align="center">
    <el-table-column
      property="title"
      label=""
      width="300px"
      align="center">
    </el-table-column>
    <el-table-column
      property="input"
      lable=""
      width="300px"
      align="center"
      >
      <template slot-scope="scope">
        <el-input  v-model="scope.row.input" placeholder="请输入内容"></el-input>
      </template>
    </el-table-column>
  </el-table>
  <el-table
    ref="singleTable"
    :data="tableData2"
    highlight-current-row

    style="width: 100%"
    align="center">
    <el-table-column
      property="title"
      label=""
      width="300px"
      align="center">
    </el-table-column>
    <el-table-column
      property="iminput"
      lable=""
      width="300px"
      align="center"
      >
      <template slot-scope="scope">
        <input type="file" id="image" name="image" @change="preview($event)">
      </template>
    </el-table-column>
  </el-table>
  <el-button round v-on:click="sendChanage">确认修改</el-button>
</div>
</template>
<script>
export default {
  name: 'cookmanager',
  data () {
    return {
      name:'',
      price:0,
      img_url:"",
      tableData: [{
          title: '菜品名',input:null
        },{
            title: '菜品价格',input:null
          }],
        tableData2: [{
            title: '选择预览图',
          }],
        currentRow: null
    }
  },
  methods: {
    preview(event){
      this.imgDataUrl = event.target.files;
    },
    open3(){
      this.$router.go(-1)
    },
    sendChanage(){
      let thi=this
      console.log('changeFood');
      console.log(this.tableData[0].input);
        console.log(this.tableData[1].input);
      let food =this.$store.getters.getCurrentChangeFood
      if(this.tableData[1].input){
        food.price=this.tableData[1].input
      }
      if(this.tableData[0].input){
          food.foodName=this.tableData[0].input
      }
      this.jquery.ajax({
        type:"post",
        crossDomain: true,
         xhrFields: {withCredentials: true},
        url:"http://127.0.0.1:8080/BookDinner-Server/sale/updateFood.action",
        async:true,
        headers: {
           'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8'
        },
        dataType: "json",
        data:{
          'id':food.id,
          "abs":food.abs,
          "foodName":food.foodName,
          "cuisineId":food.cuisineId,
          "hotSale":food.hotSale,
          'imgUrl':food.imgUrl,
          "isPublished":food.isPublished,
          "price":food.price,
          "sale":food.sale
        },
        success:function(date){

          if(date.status=='-1'){

          }else{
            thi.$message({
              type: 'success',
              message: '成功修改' 
            });
            console.log(food.foodName);
            thi.$store.commit('updateCurrentChangeFood',food)
            thi.$store.commit('saveCurrentChangeFood',food)

          }
          }
        })



    }
  }
}
</script>
