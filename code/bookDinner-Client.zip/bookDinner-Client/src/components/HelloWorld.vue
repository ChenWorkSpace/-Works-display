<template>

     <div class="hello col-xs-12" >
          <div class="welcome">
            <h1 class="title">{{ msg }}</h1>
          </div>
     </div>



</template>

<script>
export default {
  name: 'HelloWorld',
  data () {
    return {
      init:true,
      msg: 'Welcome to BookDinner'
    }
  },
  mounted:function(){
    const thi=this;
     setTimeout(function(){
       if(thi.$store.getters.getUser){
         if(thi.$store.getters.getUser.password){
              thi.$router.push({path:"/UserManager/HeadPage"})
         }
       }else{
           thi.$router.push({path:"Login"})
       }
     },600);
  },
  watch: {
    '$route' (to, from) {
    let toDepth = 0;
    if(from.name=="HelloWorld"|| this.init==true){
      toDepth=0;
      this.init=false;
    }else{
      toDepth=1;
    }


    }
  },

  methods:{


  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
h1, h2 {
  font-weight: normal;
}
ul {
  list-style-type: none;
  padding: 0;
}
li {
  display: inline-block;
  margin: 0 10px;
}
a {

}
.hello{

}

.title{
  margin-top: 150px;
  color: #409EFF;
}

.slide-left-enter,
 .slide-right-leave-active {

    -webkit-transform: translate(0,100%);
    transform: translate(, 100%);
}

.slide-left-leave-active,
.slide-right-enter {

    -webkit-transform: translate(0, -100%);
    transform: translate( 0,-100%);
}



</style>
