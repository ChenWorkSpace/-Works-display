<template>
<div>
  <h1 align='lef'>用户管理</h1>
  <el-table
      :data="tableData"
      border
      style="width: 100%">
      <el-table-column
        fixed
        prop="date"
        label="创建日期"
        width="150">
      </el-table-column>
      <el-table-column
        prop="name"
        label="用户名"
        width="150">
      </el-table-column>
      <el-table-column
        prop="phone"
        label="电话"
        width="150">
      </el-table-column>
      <el-table-column
        prop="address"
        label="收货地址"
        width="300">
      </el-table-column>
      <el-table-column
        prop="id"
        label="账号"
        width="120">
      </el-table-column>
      <el-table-column
        fixed="right"
        label="操作"
        >
        <template slot-scope="scope">
          <el-button v-on:click="clicks4"
            size="mini"
            @click="handleEdit(scope.$index, scope.row)">编辑</el-button>
          <el-button
            size="mini"
            type="danger"
            @click="handleDelete(scope.$index, scope.row)">删除</el-button>
        </template>
      </el-table-column>
    </el-table>
    <div><el-button v-on:click="clicks2"  type="primary"@click="onSubmit">返回主页</el-button></div>
  </div>
</template>

<script>
export default {
  name:'Home',
   methods: {
     handleClick(row) {
       console.log(row);
     },
     clicks2:function(){
       this.$router.push({path:"/"})
     },
     clicks4:function(){
       this.$router.push({path:"edit"})
     }
   },

   data() {
     return {
       tableData: [{
         date: '2018-1-10',
         name: '赵伟伟',
         phone: '15247124053',
         address: '内蒙古工业大学',
         id: 1
       }, {
         date: '2018-1-10',
         name: '陈广平',
         phone: '15247124053',
         address: '内蒙古工业大学',
         id: 2
       }, {
         date: '2018-1-10',
         name: '张鹏',
         phone: '15247124053',
         address: '内蒙古工业大学',
         id: 3
       }, {
         date: '2018-1-10',
         name: '段镭',
         phone: '15247124053',
         address: '内蒙古工业大学',
         id: 4
       }]
     }

   }

 }

</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>

h1, h2 {
  font-weight: normal;
}
ul {
  list-style-type: none;
  padding: 0;
}
li {
  display: inline-block;
  margin: 0 10px;
}
a {
  color: #42b983;
}
</style>
