<template>
<div class="headpage col-xs-12">


  <div class="row">
    <div class="row">
    <div class="block">
       <el-carousel height="300px">

         <el-carousel-item v-for="(item,index) in banner_list" :key="index">
             <img   alt="" :src="item.img_url" style="min-height:300px;width:100%;*zoom:1; ">
           <p>{{item.img_url}}</p>
         </el-carousel-item>
       </el-carousel>
     </div>

    </div>
  </div>


  <div class="row">
    <div class="col-xs-12" >
      <h3 style="float:left;margin-left:15px;">热销</h3>
      <p style="float:left;margin-left:10px;color:#999;font-size:12px;margin-top:30px;">大家喜欢吃，才叫真好吃。</p>
    </div>
  </div>

  <div class="row" style="padding:15px;">


    <div class="col-xs-12 col-lg-6">


      <el-card v-for="(item,index) in hot_sale_left" :key="index" :body-style="{ padding: '0px' }" style="height:120px;margin-right:20px;margin-bottom:15px;">
          <!-- <img src="~examples/assets/images/hamburger.png" class="image"> -->
          <div v-lazy:background-image.container="item.imgUrl" class="img" style="height:120px;width:120px;float:left;"></div>
          <div style="padding: 10px;float:left;width:75%;" >
            <h3 style="font-size: 14px;font-weight: 700;margin:0px;float:left;" >{{item.foodName}}</h3>
            <div class="bottom clearfix" style="padding-top:10px;clear:both;height:60px;">
              <p style="color:#999;float:left;">{{item.abs}}</p>
            </div>

            <div class="" style="margin-left:4px;">
              <i class="fa fa-jpy" style="color:#f74342;float:left;"></i>
              <p style="margin-top:-4px;margin-left:4px;float:left;color:#f74342;font-size:16px;font-weight:700;">{{item.price}}</p>
              <p style="margin-top:-4px;margin-left:18px;float:left;font-size:14 px;font-weight:700;">销量:</p>
              <p style="margin-top:-4px;margin-left:4px;float:left;font-size:14 px;font-weight:700;" >{{item.sale}}</p>
              <p style="float:left;margin-top:-4px;margin-left:10px;">(天)</p>
                <el-button type="primary" style="float:right;margin-top:-10px;height:35px;width:100px;font-size:12px;" v-on:click="addBuyBus(item)" round>加入购物车</el-button>
            </div>
          </div>ponter
        </el-card>
    </div>
    <div class="col-xs-12 col-lg-6" >


      <el-card v-for="(item,index) in hot_sale_right" :key="index" :body-style="{ padding: '0px' }" style="height:120px;margin-left:20px;margin-bottom:15px">
          <!-- <img src="~examples/assets/images/hamburger.png" class="image"> -->
          <div v-lazy:background-image.container="item.imgUrl" class="img" style="height:120px;width:120px;float:left;"></div>
          <div style="padding: 10px;float:left;width:75%;" >
            <h3 style="font-size: 14px;font-weight: 700;margin:0px;float:left;" >{{item.foodName}}</h3>
            <div class="bottom clearfix" style="padding-top:10px;clear:both;height:60px;">
              <p style="color:#999;float:left;">{{item.abs}}</p>
            </div>

            <div class="" style="margin-left:4px;">
              <i class="fa fa-jpy" style="color:#f74342;float:left;"></i>
              <p style="margin-top:-4px;margin-left:4px;float:left;color:#f74342;font-size:16px;font-weight:700;">{{item.price}}</p>
              <p style="margin-top:-4px;margin-left:18px;float:left;font-size:14 px;font-weight:700;">销量:</p>
              <p style="margin-top:-4px;margin-left:4px;float:left;font-size:14 px;font-weight:700;" >{{item.sale}}</p>
              <p style="float:left;margin-top:-4px;margin-left:10px;">(天)</p>
                <el-button type="primary" style="float:right;margin-top:-10px;height:35px;width:100px;font-size:12px;" v-on:click="addBuyBus(item)" round>加入购物车</el-button>
            </div>
          </div>
        </el-card>
    </div>


    <div class="col-xs-12" style="margin-bottom:30px;">

    </div>
  </div>
  <div class="row" style="padding:15px;">
  <el-tabs v-model="activeName" @tab-click="handleClick">
  <el-tab-pane v-for="(item,index) in book_list" :key="index"  style="font-weight:700;" :label="item.cuisineName" :name="item.index"></el-tab-pane>
</el-tabs>
  </div>
  <div class="row"  style="padding:15px;">

        <div class="col-xs-12 col-lg-6">


          <el-card v-for="(item,index) in cuisine_food_left" :key="index" :body-style="{ padding: '0px' }" style="height:120px;margin-right:20px;margin-bottom:15px;">
              <!-- <img src="~examples/assets/images/hamburger.png" class="image"> -->
              <div v-lazy:background-image.container="item.imgUrl" class="img" style="height:120px;width:120px;float:left;"></div>
              <div style="padding: 10px;float:left;width:75%;" >
                <h3 style="font-size: 14px;font-weight: 700;margin:0px;float:left;" >{{item.foodName}}</h3>
                <div class="bottom clearfix" style="padding-top:10px;clear:both;height:60px;">
                  <p style="color:#999;float:left;">{{item.abs}}</p>
                </div>

                <div class="" style="margin-left:4px;">
                  <i class="fa fa-jpy" style="color:#f74342;float:left;"></i>
                  <p style="margin-top:-4px;margin-left:4px;float:left;color:#f74342;font-size:16px;font-weight:700;">{{item.price}}</p>
                  <p style="margin-top:-4px;margin-left:18px;float:left;font-size:14 px;font-weight:700;">销量:</p>
                  <p style="margin-top:-4px;margin-left:4px;float:left;font-size:14 px;font-weight:700;" >{{item.sale}}</p>
                  <p style="float:left;margin-top:-4px;margin-left:10px;">(天)</p>
                    <el-button type="primary" style="float:right;margin-top:-10px;height:35px;width:100px;font-size:12px;" v-on:click="addBuyBus(item)" round>加入购物车</el-button>
                </div>
              </div>
            </el-card>
        </div>
        <div class="col-xs-12 col-lg-6" >


          <el-card v-for="(item,index) in cuisine_food_right" :key="index" :body-style="{ padding: '0px' }" style="height:120px;margin-left:20px;margin-bottom:15px">
              <!-- <img src="~examples/assets/images/hamburger.png" class="image"> -->
              <div v-lazy:background-image.container="item.imgUrl" class="img" style="height:120px;width:120px;float:left;"></div>
              <div style="padding: 10px;float:left;width:75%;" >
                <h3 style="font-size: 14px;font-weight: 700;margin:0px;float:left;" >{{item.foodName}}</h3>
                <div class="bottom clearfix" style="padding-top:10px;clear:both;height:60px;">
                  <p style="color:#999;float:left;">{{item.abs}}</p>
                </div>

                <div class="" style="margin-left:4px;">
                  <i class="fa fa-jpy" style="color:#f74342;float:left;"></i>
                  <p style="margin-top:-4px;margin-left:4px;float:left;color:#f74342;font-size:16px;font-weight:700;">{{item.price}}</p>
                  <p style="margin-top:-4px;margin-left:18px;float:left;font-size:14 px;font-weight:700;">销量:</p>
                  <p style="margin-top:-4px;margin-left:4px;float:left;font-size:14 px;font-weight:700;" >{{item.sale}}</p>
                  <p style="float:left;margin-top:-4px;margin-left:10px;">(天)</p>
                    <el-button type="primary" style="float:right;margin-top:-10px;height:35px;width:100px;font-size:12px;" v-on:click="addBuyBus(item)" round>加入购物车</el-button>
                </div>
              </div>
            </el-card>
        </div>

  </div>
  <div class="row">
  <div class="col-xs-4 col-lg-3 navbar-fixed-bottom col-lg-offset-9"v-if="show_buy_bus" >
    <div class="line row"  style="height:2px;background-color:#0089DC;">

    </div>
<div class="row box-head" style="height:50px;background-color:#FAFAFA;">
<p style="float:left;margin-top:8px;margin-left:8px;font-size:15px;">购物车</p>
<a style="float:left;margin-top:8px;margin-left:8px;cursor:pointer;" v-on:click="clearBuyBus">[清空]</a>
</div>
<div class="row box-content" style="background-color:#ffffff;">
  <div v-for="(item,index) in buy_bus"  class="col-xs-12" style="height:50px;padding-top:10px;padding-left:15px;padding-right:15px;">
   <p  style="float:left;">{{item.foodName}}</p>
  <p style="float:right;color:#F17530;" >{{item.price}}</p>
  <span class="fa fa-jpy" style="color:#F17530;float:right;margin-top:4px;margin-left:15px;margin-right:3px;"></span>
   <p style="float:right;">x{{item.count}}</p>
   <div v-on:click="removeBuyBus(item)" style="float:right;width:10px;height:3px;background-color:#0089DC;margin-right:25px;margin-top:9px;cursor:pointer;"></div>

  </div>

</div>
<div class="row box-footer" style="height:50px;" >
  <div class="col-xs-7"  style="background-color:#2C2C2C;height:50px;">
    <span class=" fa fa-cart-plus fa-2x" style="color:#ffffff;float:left;margin-top:10px;margin-left:10px;"></span>
    <span class="fa fa-jpy" style="color:#ffffff;float:left;margin-top:22px;margin-left:8px;"></span>
    <p style="color:#ffffff;float:left;margin-top:8px;margin-left:3px;font-weight:500;font-size:24px;">{{count_price}}</p>
  </div>
  <div class="col-xs-5" style="background-color:#51D862;;height:50px;">
    <p style="color:#ffffff;font-weight:700;margin-top:15px;cursor:pointer;" v-on:click="settlement">去结算 ></p>
  </div>
</div>
    </div>
  </div>

</div>
</template>

<script>
export default {
  name: 'HeadPage',
  data () {
    return {
      count_price:0,
      show_buy_bus:false,
      current_tab:'0',
      trans:"slid-left",
      activeName: '0',
      buy_bus:[],
      hot_sale_left:[],
      cuisine_food_left:[],
      cuisine_food_right:[],
      hot_sale_right:[{abs:'awd'},{abs:'awd'}],
        banner_list:[
          {img_url:' /static/img/back_4.jpg',
           click_url:""},
          {img_url:"/static/img/back_5.jpg",
           click_url:""},
          {img_url:"/static/img/back_6.jpg",
           click_url:""},
          {img_url:"/static/img/back_7.png",
           click_url:""}
        ],
        book_list:[],
        currentRow: null
    }
  },
  mounted:function(){
    let thi=this
    let settlement=this.$store.getters.getSettlementItem;
    if(settlement){
      this.count_price=settlement.count_price
      this.buy_bus=settlement.buy_bus
      this.show_buy_bus=true
    }
    if(this.$store.getters.getCuisineList){
        this.book_list=this.$store.getters.getCuisineList
        this.cuisine_food_left=this.$store.getters.getListLeft(this.$store.getters.getCuisineFood(this.$store.getters.getSelectedCusineFoodId),this.$store.state.cuisine_food_left,'cuisine_food_left')
        this.cuisine_food_right=this.$store.getters.getListRight(this.$store.getters.getCuisineFood(this.$store.getters.getSelectedCusineFoodId),this.$store.state.cuisine_food_right,'cuisine_food_right')

    }
   if(!this.$store.getters.getCuisineList){

     this.jquery.ajax({
       type:"post",
       crossDomain: true,
        xhrFields: {withCredentials: true},
       url:"http://127.0.0.1:8080/BookDinner-Server/sale/getCuisineList.action",
       async:true,
       headers: {
          'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8'
       },
       dataType: "json",
       data:{},
       success:function(date){
          let th=thi
         if(date.status=='-1'){

         }else{
           let th=thi
             thi.$store.commit('updateCuisineList', date.results)
             thi.book_list=thi.$store.getters.getCuisineList
              console.log('cehckStatusrespons'+thi.$store.getters.getCuisineList);
                thi.jquery.ajax({
                  type:"post",
                  crossDomain: true,
                   xhrFields: {withCredentials: true},
                  url:"http://127.0.0.1:8080/BookDinner-Server/sale/getFoodList.action",
                  async:true,
                  headers: {
                     'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8'
                  },
                  dataType: "json",
                  data:{
                    'cuisine_id':thi.$store.getters.getCuisineList[0].id
                  },
                  success:function(date){

                     console.log('host_sale',date.status);
                     console.log('host_sale',date.results);
                    if(date.status=='-1'){

                    }else{
                        date['id']=th.$store.getters.getCuisineList[0].id
                        th.$store.commit('updateCusineFood', date)
                        th.$store.commit('updateSelectedCusineFoodId', th.book_list[0].id)
                          th.cuisine_food_left=th.$store.getters.getListLeft(th.$store.getters.getCuisineFood(th.$store.getters.getSelectedCusineFoodId),th.$store.state.cuisine_food_left,'cuisine_food_left')
                          th.cuisine_food_right=th.$store.getters.getListRight(th.$store.getters.getCuisineFood(th.$store.getters.getSelectedCusineFoodId),th.$store.state.cuisine_food_right,'cuisine_food_right')

                    }
                    }
                  })

         }
         }
         })
   }
   if(!this.$store.getters.getHotSale){
     this.jquery.ajax({
       type:"post",
       crossDomain: true,
        xhrFields: {withCredentials: true},
       url:"http://127.0.0.1:8080/BookDinner-Server/sale/getHotSale.action",
       async:true,
       headers: {
          'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8'
       },
       dataType: "json",
       data:{},
       success:function(date){
          let th=thi
          console.log('host_sale',date.status);
          console.log('host_sale',date.results);
         if(date.status=='-1'){

         }else{
             thi.$store.commit('updateHotSale', date.results)
             thi.hot_sale_left=thi.$store.getters.getListLeft(thi.$store.getters.getHotSale,thi.$store.state.hot_sale_left,'hot_sale_left')
             thi.hot_sale_right=thi.$store.getters.getListRight(thi.$store.getters.getHotSale,thi.$store.state.hot_sale_right,'hot_sale_right')

         }
         }
         })
   }else{
     this.hot_sale_left=this.$store.getters.getListLeft(this.$store.getters.getHotSale,this.$store.state.hot_sale_left,'hot_sale_left')
     this.hot_sale_right=this.$store.getters.getListRight(this.$store.getters.getHotSale,this.$store.state.hot_sale_right,'hot_sale_right')

   }







  },
  methods:{

    settlement:function(){
      let bus={'count_price':this.count_price,buy_bus:this.buy_bus,'create_time':Date.parse(new Date()),"addr":this.$store.getters.getUser.addr}
      bus["number"]=""+bus['create_time']
      bus["userId"]=this.$store.getters.getUser.id
      this.$store.commit('updateSettlementItem',bus)
      this.$router.push({path:"/UserManager/UserOrderConfirm"})

    },
    clearBuyBus:function(){
        this.buy_bus=[]
        this.show_buy_bus=false
    },
    removeBuyBus:function(item){
      if(item.count==1){
        for (var i=0;i<this.buy_bus.length;i++) {
          if(this.buy_bus[i].id==item.id){
            this.buy_bus.splice(i,1)
              this.$options.methods.computePrice(this)
          }
        }
      }else{
        for (var i=0;i<this.buy_bus.length;i++) {
          if(this.buy_bus[i].id==item.id){
            item.count=item.count-1
            this.buy_bus.splice(i,1,item)
              this.$options.methods.computePrice(this)
          }
        }
      }
      if(this.buy_bus.length==0){
          this.show_buy_bus=false;
      }
    },
    addBuyBus:function(item){
      for (var i=0;i<this.buy_bus.length;i++) {
        console.log('item_id:'+item.id+'  buy_bus_id:'+this.buy_bus.id);
        if(this.buy_bus[i].id==item.id){
          item['count']=this.buy_bus[i]['count']+1
          this.buy_bus.splice(i,1,item)
          this.$options.methods.computePrice(this)
          return
        }
      }
      this.show_buy_bus=true;
      item['count']=1
      this.buy_bus.unshift(item)
        this.$options.methods.computePrice(this)
    },
    computePrice(thi){
        thi.count_price=0
      for (var i=0;i<thi.buy_bus.length;i++) {
        thi.count_price+=thi.buy_bus[i].count*thi.buy_bus[i].price
      }
    },
    handleClick(tab, event) {
      if(this.current_tab>tab.index){
        if(this.trans){
          this.trans="slid-right"
        }
      }else{
        if(this.trans){
          this.trans="slid-left"
        }
      }


      if(!this.$store.getters.getCuisineFood(this.$store.getters.getCuisineList[tab.index])){
        let thi=this
        this.jquery.ajax({
          type:"post",
          crossDomain: true,
           xhrFields: {withCredentials: true},
          url:"http://127.0.0.1:8080/BookDinner-Server/sale/getFoodList.action",
          async:true,
          headers: {
             'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8'
          },
          dataType: "json",
          data:{
            'cuisine_id':this.$store.getters.getCuisineList[tab.index].id
          },
          success:function(date){
             let th=thi
             console.log('host_sale',date.status);
             console.log('host_sale',date.results);
            if(date.status=='-1'){

            }else{
                date['id']=thi.$store.getters.getCuisineList[tab.index].id
                thi.$store.commit('updateCusineFood', date)
                thi.$store.commit('updateSelectedCusineFoodId', thi.book_list[tab.index].id)
                  thi.cuisine_food_left=thi.$store.getters.getListLeft(thi.$store.getters.getCuisineFood(thi.$store.getters.getSelectedCusineFoodId),thi.$store.state.cuisine_food_left,'cuisine_food_left')
                  thi.cuisine_food_right=thi.$store.getters.getListRight(thi.$store.getters.getCuisineFood(thi.$store.getters.getSelectedCusineFoodId),thi.$store.state.cuisine_food_right,'cuisine_food_right')

            }
            }
          })
        }
        this.cuisine_food_left=this.$store.getters.getListLeft(this.$store.getters.getCuisineFood(this.$store.getters.getSelectedCusineFoodId),this.$store.state.cuisine_food_left,'cuisine_food_left')
        this.cuisine_food_right=this.$store.getters.getListRight(this.$store.getters.getCuisineFood(this.$store.getters.getSelectedCusineFoodId),this.$store.state.cuisine_food_right,'cuisine_food_right')
      this.$store.commit('updateSelectedCusineFoodId', this.book_list[tab.index].id)
      this.current_tab=tab.index;
      this.$store.commit('updateBookDel', true)
       console.log(tab, event);
       console.log(tab.index);
     },

    handleEdit(index,row){
      this.$router.push({path:"/cookviewa"})
    },
   handleCurrentChange(val) {
     this.currentRow = val;
   }
  }
}
</script>

<style scoped="">
.router {
     position: absolute;
     width: 100%;
     transition: all .30s ;

}
.slid-left-enter,
 .slid-right-leave-active {
    -webkit-transform: translate(100%, 0);
    transform: translate(100%, 0);
}

.img{

 background-size: cover;
}

.slid-left-leave-active,
.slid-right-enter {

    -webkit-transform: translate(-100%, 0);
    transform: translate(-100%, 0);
}
</style>

<!-- Add "scoped" attribute to limit CSS to this component only -->
