<template>
<div class="row">
  <h1 align="left">最近订单</h1>
  <el-table
    :data="tableData3"
    border
    style="width: 100%;">
    <el-table-column
    align="center"
      prop="userId"
      label="用户"
      width="200px">
    </el-table-column>
    <el-table-column
    align="center"
      prop="create_time"
      label="日期"
      width="150px">
    </el-table-column>
    <el-table-column
    align="center"
      prop="number"
      label="名称"
    width="350px"
      >
    </el-table-column>
    <el-table-column
    align="center"
      prop="count_price"
      label="小计(元)"
    width="150px">
    </el-table-column>
    <el-table-column
    align="center"
      prop="status"
      label="状态"
    width="200px">
    </el-table-column>

    <el-table-column
    align="center"
      label="操作"
      width="250px">
      <template slot-scope="scop">
        <el-button @click="handleClick(scop.row)" type="text" size="small">订单详情</el-button>
        <el-button type="text" size="small"  @click="backPage(scop.row)">删除订单</el-button>
      </template>
    </el-table-column>
  </el-table>
</div>
</template>
<script>


  export default {
    data() {
      return {
        online:true,
        tableData3: []
      }

    },watch: {
      '$route' (to, from) {
    const thi=this
    console.log('to'+ to.name);
    console.log('from'+ from.name);



      }
    },
    mounted:function(){
      if(this.online){
        let thi=this
        this.online=false
        this.jquery.ajax({
          type:"post",
          crossDomain: true,
           xhrFields: {withCredentials: true},
          url:"http://127.0.0.1:8080/BookDinner-Server/sale/getAllOrderRecord.action",
          async:true,
          headers: {
             'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8'
          },
          dataType: "json",
          data:{

          },
          success:function(date){
            if(date.status=='-1'){

            }else{
              var formatDateTime = function (date) {
                var y = date.getFullYear();
                var m = date.getMonth() + 1;
                m = m < 10 ? ('0' + m) : m;
                var d = date.getDate();
                d = d < 10 ? ('0' + d) : d;
                var h = date.getHours();
                var minute = date.getMinutes();
                minute = minute < 10 ? ('0' + minute) : minute;
                return y + '-' + m + '-' + d+' '+h+':'+minute;
              }
                for(let i=0;i<date.results.length;i++){
                  let order={}
                  order['count_price']=date.results[i]['countPrice']
                  let time =new Date(date.results[i]['createTime'].time)
                  order['create_time']=formatDateTime(time)
                  order['timestap']=date.results[i]['createTime'].time
                  order['addr']=date.results[i]['addr']
                  order['status']=date.results[i]['status']

                  order['number']=date.results[i]['number']
                  order['userId']=date.results[i]['userId']
                    console.log(order['number']);
                  order['buy_bus']=[]
                  thi.tableData3.unshift(order)
                }
            }
            }
          })
      }


    },
    methods:{
      handleClick:function(item){
        let thi=this
        console.log(item.date);
        let order={}
          order['count_price']=item['count_price']
          order['create_time']=item['timestap']
          order['addr']=item['addr']
          order['status']=item['status']
          order['number']=item['number']
          order['userId']=item['userId']
          order['buy_bus']=[]
        this.jquery.ajax({
          type:"post",
          crossDomain: true,
           xhrFields: {withCredentials: true},
          url:"http://127.0.0.1:8080/BookDinner-Server/sale/getOrderFood.action",
          async:true,
          headers: {
             'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8'
          },
          dataType: "json",
          data:{
            'number':item.number
          },
          success:function(date){
            if(date.status=='-1'){

            }else{
              for(let i=0;i<date.results.length;i++){
                   date.results[i][0]['count']=date.results[i][1]
                   order['buy_bus'].unshift(date.results[i][0])
                }
              }
              thi.$store.commit('updateSettlementItem',order)
              thi.$router.push({path:"/Manager/OrderManagement/OrderDetails"})
            }

          })

      },
      backPage:function(item){
        let thi=this
        this.jquery.ajax({
          type:"post",
          crossDomain: true,
           xhrFields: {withCredentials: true},
          url:"http://127.0.0.1:8080/BookDinner-Server/sale/delOrder.action",
          async:true,
          headers: {
             'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8'
          },
          dataType: "json",
          data:{
            'number':item.number
          },
          success:function(date){
            if(date.status=='-1'){

            }else{
               for(let i=0;i<thi.tableData3.length;i++){
                 console.log(thi.tableData3[i].number);
                 console.log(item['number']);
                 if(thi.tableData3[i].number==item['number']){
                   thi.tableData3.splice(i,1)
                   thi.$message({
                     type: 'success',
                     message: '成功删除'
                   });
                 }
               }
            }
          }
          })
    }
  }
}
</script>
