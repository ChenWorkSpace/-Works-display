<template>
  <div class="client row" >

  <div class="line"></div>
  <el-menu
    :default-active="activeIndex2"
    class="el-menu-demo"
    mode="horizontal"
    @select="handleSelect"
    background-color="#545c64"
    text-color="#fff"
    active-text-color="#409EFF">
    <h2 class="managerH1">Manager</h2>
    <el-menu-item index="1">订单管理</el-menu-item>
    <!-- <el-submenu index="2">
      <template slot="title">我的工作台</template>
      <el-menu-item index="2-1">选项1</el-menu-item>
      <el-menu-item index="2-2">选项2</el-menu-item>
      <el-menu-item index="2-3">选项3</el-menu-item>
    </el-submenu> -->
    <el-menu-item index="2">菜系管理</el-menu-item>
    <el-menu-item index="3">菜品管理</el-menu-item>
    <el-menu-item index="4"><a href="https://www.ele.me" target="_blank">订单管理</a></el-menu-item>
  </el-menu>

  <transition :name="transitionName">
    <router-view   class="manager-pager" ></router-view>
  </transition>





  </div>


</template>

<script>
export default {
  name: 'manager',
  data () {
    return {
      msg:"Manager"
    }
  },
  methods:{

  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
h1, h2 {
  font-weight: normal;
}
ul {
  list-style-type: none;
  padding: 0;
}
li {
  display: inline-block;
  margin: 0 10px;
}
.clientH1{
  color: #ffffff;
  float:left;
  margin-left:10px;
  margin-top:10px;
  margin-right:20px;

}
.manager{

}
</style>
