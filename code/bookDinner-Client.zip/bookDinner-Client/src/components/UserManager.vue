<template>
  <div class="UserManager row" >
    <div class="col-xs-12">
      <div class="row">
        <div class="line"></div>
        <el-menu
          :default-active="activeIndex2"
          class="el-menu-demo row"
          mode="horizontal"
          @select="handleSelect"
          background-color="#545c64"
          text-color="#fff"
          active-text-color="#409EFF">
          <h2 class="managerH1">就是饿</h2>
          <el-menu-item index="1">首页</el-menu-item>
          <el-menu-item index="2">我的订单</el-menu-item>
            <el-input placeholder="请输入内容" v-model="input5" class="" style="width:40%;margin-top:12px;float:left;margin-left:50px;">
            <el-button slot="append" icon="el-icon-search"></el-button>
            </el-input>
            <router-link  class="title" index='3' to="/UserManager/Center"  style="float:right;margin-right:35px;margin-top:20px;" >{{username}}</router-link>
            <h4 v-on:click='toUserPage' class="welcome title" style="float:right;margin-right:15px;margin-top:20px;">欢迎光临!</h4>
            <p  class="title" index='4' to="/UserManager/Logout"   style="float:right;margin-right:35px;margin-top:20px;cursor:pointer;" v-on:click="logOut">退出</p>
        </el-menu>
        <div class="row">
        <transition :name="trans">
              <router-view class="manager-router" ></router-view>
        </transition>
        </div>
        </div>
      </div>

    </div>





</template>

<script>
export default {

  name: 'UserManager',
  data () {
    return {
      username:"",
      input5: '',
     select: '',
      current:"1",
      trans:"slid-left",
      msg:"Manager",
      activeIndex2: '1',
    }
  },
  mounted:function(){
    console.log('userManger'+this.$store.getters.getUser.username);
    this.username=this.$store.getters.getUser.username


  },
  methods:{
    logOut(){
      let thi=this
      this.jquery.ajax({
        type:"post",
        crossDomain: true,
         xhrFields: {withCredentials: true},
        url:"http://127.0.0.1:8080/BookDinner-Server/logout.action",
        async:true,
        headers: {
           'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8'
        },
        dataType: "json",
        success:function(date){
        thi.$store.commit('updateUser',null)
        thi.$router.push({path:"/Login"})
      }
    })

    },
    toUserPage:function(){

    },
    handleSelect(key, keyPath) {
      if(this.current>key){
        if(this.trans){
          this.trans="slid-right"
        }
      }else{
        if(this.trans){
          this.trans="slid-left"
        }
      }
      this.current=key;
      switch (key) {
        case "1":
          this.$router.push({path:"/UserManager/HeadPage"})
          break;
        case "2":
         this.$router.push({path:"/UserManager/UserOrderManagement"})
          break;
        case "3":
        default:

      }
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
.el-carousel__item h3 {
   color: #475669;
   font-size: 14px;
   opacity: 0.75;
   line-height: 150px;
   margin: 0;
 }

 .el-carousel__item:nth-child(2n) {

 }

 .el-carousel__item:nth-child(2n+1) {

 }
 .title{
   color:#ffffff;
 }
h1, h2 {
  font-weight: normal;
}
ul {
  list-style-type: none;
  padding: 0;
}
li {
  display: inline-block;
  margin: 0 10px;
}
.managerH1{
  color: #ffffff;
  float:left;
  margin-left:10px;
  margin-top:10px;
  margin-right:20px;

}
.manager{

}

.manager-router {
     position: absolute;
     width: 100%;
     transition: all .30s ;

}
.slid-left-enter,
 .slid-right-leave-active {
    -webkit-transform: translate(100%, 0);
    transform: translate(100%, 0);
}

.slid-left-leave-active,
.slid-right-enter {

    -webkit-transform: translate(-100%, 0);
    transform: translate(-100%, 0);
}

.manager-router {
     position: absolute;
     width: 100%;
     transition: all .30s ;

}
.slid-left-enter,
 .slid-right-leave-active {
    -webkit-transform: translate(100%, 0);
    transform: translate(100%, 0);
}

.slid-left-leave-active,
.slid-right-enter {

    -webkit-transform: translate(-100%, 0);
    transform: translate(-100%, 0);
}
</style>
