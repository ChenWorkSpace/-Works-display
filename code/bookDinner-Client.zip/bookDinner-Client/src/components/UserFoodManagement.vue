<template>
<el-container style="height: 600px; width: 600px; border: 1px solid #eee">
  <el-aside width="200px" style="background-color: rgb(238, 241, 246)">
    <el-menu>
      <el-menu-item index="1">
        <template slot="title"><h1 v-on:click="clicka">川菜</h1></template>
      </el-menu-item>
      <el-menu-item index="2">
        <template slot="title"><h1 v-on:click="clickb">鲁菜</h1></template>
      </el-menu-item>
      <el-menu-item index="3">
        <template slot="title"><h1 v-on:click="clickc">粤菜</h1></template>
      </el-menu-item>
      <el-menu-item index="4">
        <template slot="title"><h1 v-on:click="clickd">苏菜</h1></template>
      </el-menu-item>
      <el-menu-item index="5">
        <template slot="title"><h1 v-on:click="clicke">浙菜</h1></template>
      </el-menu-item>
      <el-menu-item index="6">
        <template slot="title"><h1 v-on:click="clickf">闽菜</h1></template>
      </el-menu-item>
      <el-menu-item index="7">
        <template slot="title"><h1 v-on:click="clickg">湘菜</h1></template>
      </el-menu-item>
      <el-menu-item index="8">
        <template slot="title"><h1 v-on:click="clickh">徽菜</h1></template>
      </el-menu-item>
    </el-menu>
  </el-aside>
  <el-main width="200px">
    <router-view></router-view>
    </el-main>
  </el-container>
</el-container>
</template>

<script>
    export default {
        name: "cookviewa",
        methods: {
            clicka:function() {
              this.$router.push({path:"/cookviewa/a"})
            },
            clickb:function() {
              this.$router.push({path:"/cookviewa/b"})
            },
            clickc:function() {
              this.$router.push({path:"/cookviewa/c"})
            },
            clickd:function() {
              this.$router.push({path:"/cookviewa/d"})
            },
            clicke:function() {
              this.$router.push({path:"/cookviewa/e"})
            },
            clickf:function() {
              this.$router.push({path:"/cookviewa/f"})
            },
            clickg:function() {
              this.$router.push({path:"/cookviewa/g"})
            },
            clickh:function() {
              this.$router.push({path:"/cookviewa/h"})
            }
        }
    }
</script>
