<template lang="html">
  <div>
    <el-button round @click="open3">返回主页</el-button>
  <el-table
    ref="singleTable"
    :data="tableData"
    highlight-current-row
    style="width: 100%"
    align="center">
    <el-table-column
      property="title"
      label=""
      width="300px"
      align="center">
    </el-table-column>
    <el-table-column
      property="input"
      lable=""
      width="300px"
      align="center"
      >
      <template slot-scope="scope">
        <el-input v-model="scope.row.input" placeholder="请输入内容"></el-input>
      </template>
    </el-table-column>
  </el-table>
  <el-table
    ref="singleTable"
    :data="tableData2"
    highlight-current-row
    style="width: 100%"
    align="center">
    <el-table-column
      property="title"
      label=""
      width="300px"
      align="center">
    </el-table-column>
    <el-table-column
      property="iminput"
      lable=""
      width="300px"
      align="center"
      >
      <template slot-scope="scope">
        <input type="file" id="image" name="image" @change="preview($event)">
      </template>
    </el-table-column>
  </el-table>
  <el-button round v-on:click="sendChange">确认添加</el-button>
</div>
</template>
<script>
export default {
  name: 'cookmanager',
  data () {
    return {
      tableData: [{
          title: '菜品名',input:''
        },{
            title: '菜品价格',input:''
          }],
        tableData2: [{
            title: '选择预览图',
          }],
        currentRow: null
    }
  },
  methods: {
    sendChange:function(){
      let thi=this
      console.log('start');
      let food =this.$store.getters.getCurrentChangeFood
      if(this.tableData[1].input){
        food.price=this.tableData[1].input
      }
      if(this.tableData[0].input){
          food.foodName=this.tableData[0].input
      }
  

          this.jquery.ajax({
            type:"post",
            crossDomain: true,
             xhrFields: {withCredentials: true},
            url:"http://127.0.0.1:8080/BookDinner-Server/sale/addFood.action",
            async:true,
            headers: {
               'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8'
            },
            dataType: "json",
            data:{
              "abs":"",
              "foodName":this.tableData[0].input,
              "cuisineId":food.cuisineId,
              "hotSale":0,
              'imgUrl':"",
              "isPublished":1,
              "price":this.tableData[1].input,
              "sale":0
            },
            success:function(date){

              thi.$message({
                type: 'success',
                message: '成功添加'
              });
              console.log(food.foodName);
              thi.$store.commit('addFood',date.results)

              }
            })




    },
    preview(event){
      this.imgDataUrl = event.target.files;
    },
    open3(){
      this.$router.go(-1)
    }
  }
}
</script>
