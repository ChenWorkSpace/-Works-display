<template>
<div class="login col-xs-12" >

  <div class="panel panel-heading   col-xs-12 col-md-6 col-lg-4 col-lg-push-4    login-box text-center">
    <h1 class="col-xs-12 title">{{ msg }}</h1>
    <div class="input-group login_input_username_div "  v-bind:class="{'has-error':isWrong,'has-success':isSuccess}"  id="login_input_username_div">
      <span class="input-group-addon" style="color:#409EFF;"><i class="fa fa-user-o"></i></span>
      <input type="text" v-model='phone' name="login_username" class="form-control " id="login_input_username" :placeholder="placeholder_username" >
    </div>
    <br>
    <div class="input-group login_input_password_div" v-bind:class="{'has-error':isWrong2,'has-success':isSuccess2}" id="login_input_password_div">
      <span class="input-group-addon" style="color:#409EFF;"><i class="fa fa-key"></i></span>
      <input type="text"  v-model='password' name="login_password" id="login_input_password" class="form-control" :placeholder="placeholder_password" >
    </div>

    <button v-on:click="login(0)" type="button" class="col-xs-12 btn btn-default btn-group-vertical login-btn" name="button" style="color:#409EFF;"><i v-bind:class="{'fa fa-spinner fa-pulse':logins}"></i>登陆</button>
    <div class="col-xs-12 text-center   ">
      <router-link :to="{ name: 'Adminlogin', params: {} }"v-on:click="goAdminlogin">管理员登陆</router-link>
      <a href="#">|</a>
      <router-link :to="{ name: 'Register', params: {} }"v-on:click="goRegister">注册</router-link>


    </div>



  </div>
</div>
</template>

<script>
import '../../static/css/login.css'
export default {
  name: 'login',
  data() {
    return {
      isWrong:false,
      isSuccess:false,
      isWrong2:false,
      isSuccess2:false,
      placeholder_username:"手机号",
      placeholder_password:"密码",
      phone:'',
      password:'',
      msg: '网上订餐系统',
      logins: false
    }
  },
  created: function() {

    let heigh

  },
  watch: {
    '$route' (to, from) {
  const thi=this
  console.log('to'+ to.name);
    if(to.name=="Login"){
      if(this.$store.getters.getUser.password){
           thi.$router.push({path:"/UserManager/HeadPage"})
      }
    }


    }
  },
  mounted:function(){

  },
  methods: {
    goRegister:function(){
      this.$router.push({path:"/Register"})
    },
     goAdminlogin:function(){
      this.$router.push({path:"/Adminlogin"})
    },
    login:function(tag){

     const thi=this
     console.log('phone:'+this.phone.length);
     if(this.phone==null||this.phone.length<=1){
       this.isWrong=true
       this.placeholder_username="请输入账号信息"
       return ;
     }
     if((this.password==null||this.password.length<=1)){
       this.isWrong2=true
       this.placeholder_password="请输入账号信息"
       this.isSuccess=true
       return ;
     }else{
       this.isWrong2=false
       this.isSuccess2=true
     }
     this.jquery.ajax({
       type:"post",
       crossDomain: true,
        xhrFields: {withCredentials: true},
       url:"http://127.0.0.1:8080/BookDinner-Server/login.action",
       async:true,
       headers: {
          'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8'
       },
       dataType: "json",
       data:{
         "type":0,
         "phone":this.phone,
         "password":this.password
       },
       success:function(date){
          let th=thi
         if(date.status=='-1'){
           thi.phone=""
            thi.password=""
           thi.placeholder_username="账户或用户不存在"
           thi.isWrong=true
         }else if(date.status=='0'){
           thi.phone=""
           thi.placeholder_username="账户或密码错误"
           thi.isWrong=true
         }else{
           console.log(date.results.passwrod);
             thi.$store.commit('updateUser', date.results)
             console.log('res'+thi.$store.getters.getUser.password);
             thi.$router.push({path:"/UserManager/HeadPage"})
             thi.isSuccess=true
             thi.isSuccess2=true
         }
           }
         })

  }

}
}

</script>
<style media="screen">
.login {

}
.title{
  color: #409EFF;
}

.login-box {

  padding-left: 15px;
  padding-right: 15px;
  padding-bottom: 10px;
  margin-top: 80px;
}
</style>

<!-- Add "scoped" attribute to limit CSS to this component only -->
