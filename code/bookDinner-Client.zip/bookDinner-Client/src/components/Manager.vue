<template>
  <div class="Manager row" >

  <div class="line"></div>
  <el-menu
    :default-active="activeIndex2"
    class="el-menu-demo"
    mode="horizontal"
    @select="handleSelect"
    background-color="#545c64"
    text-color="#fff"
    active-text-color="#409EFF">
    <h2 class="managerH1">Manager</h2>
    <el-menu-item index="1">菜系管理</el-menu-item>
    <!-- <el-submenu index="2">
      <template slot="title">我的工作台</template>
      <el-menu-item index="2-1">选项1</el-menu-item>
      <el-menu-item index="2-2">选项2</el-menu-item>
      <el-menu-item index="2-3">选项3</el-menu-item>
    </el-submenu> -->
    <el-menu-item index="2">菜品管理</el-menu-item>
    <el-menu-item index="3">订单管理</el-menu-item>
  </el-menu>
<div class="col-xs-12">
  <transition :name="trans">
        <router-view class="manager-router" ></router-view>
  </transition>
</div>


  </div>



</template>

<script>
export default {

  name: 'Manager',
  data () {
    return {
      current:"1",
      trans:"sli-left",
      msg:"Manager",
      activeIndex2: '1'
    }
  },
  methods:{
    handleSelect(key, keyPath) {
      if(this.current>key){
        if(this.trans){
          this.trans="slid-right"
        }
      }else{
        if(this.trans){
          this.trans="slid-left"
        }
      }
      this.current=key;
      switch (key) {
        case "1":
          this.$router.push({path:"/Manager/CuisineManagement"})
          break;
        case "2":
         this.$router.push({path:"/Manager/FoodManagement"})
          break;
        case "3":
        this.$router.push({path:"/Manager/OrderManagement"})
        default:

      }
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
h1, h2 {
  font-weight: normal;
}
ul {
  list-style-type: none;
  padding: 0;
}
li {
  display: inline-block;
  margin: 0 10px;
}
.managerH1{
  color: #ffffff;
  float:left;
  margin-left:10px;
  margin-top:10px;
  margin-right:20px;

}
.manager{

}

.manager-router {
     position: absolute;
     width: 100%;
     transition: all .30s ;

}
.slid-left-enter,
 .slid-right-leave-active {
    -webkit-transform: translate(100%, 0);
    transform: translate(100%, 0);
}

.slid-left-leave-active,
.slid-right-enter {

    -webkit-transform: translate(-100%, 0);
    transform: translate(-100%, 0);
}
</style>
