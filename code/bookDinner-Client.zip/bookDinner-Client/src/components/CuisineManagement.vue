<template>
<div class="hello col-xs-12">
  <el-table
    ref="singleTable"
    :data="book_list"
    highlight-current-row
    @current-change="handleCurrentChange"
    style="width: 100%"
    align="center">
    <el-table-column
      type="index"
      width="200px"
      align="center">
    </el-table-column>
    <el-table-column
      property="cuisineName"
      label="菜系"
      width="300px"
      align="center">
    </el-table-column>
    <el-table-column
      property="im"
      label="预览图"
      width="300px"
      align="center"
      >
      <template slot-scope="scope">
        <img   v-lazy="scope.row.imgUrl" alt="" style="height:100px;width:100px">
      </template>
    </el-table-column>
    <el-table-column label="操作" align="center" width="300px">
      <template slot-scope="scope">
        <el-button
          size="mini"
          @click="open2(scope.row)">修改</el-button>
        <el-button
          size="mini"
          type="danger"
          @click="removetableDate(scope.$index)">删除</el-button>
      </template>
    </el-table-column>
    </el-table>
    <el-button round @click="open3">添加菜系</el-button>
</div>
</template>

<script>
export default {
  name: 'cookmanager',
  data () {
    return {
      book_list: [],
        currentRow: null
    }
  },
  mounted:function(){
    let thi=this
    if(!this.$store.getters.getCuisineList){
      this.jquery.ajax({
        type:"post",
        crossDomain: true,
         xhrFields: {withCredentials: true},
        url:"http://127.0.0.1:8080/BookDinner-Server/sale/getCuisineList.action",
        async:true,
        headers: {
           'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8'
        },
        dataType: "json",
        data:{},
        success:function(date){
           let th=thi
          if(date.status=='-1'){

          }else{
            let th=thi
              thi.$store.commit('updateCuisineList', date.results)
              thi.book_list=thi.$store.getters.getCuisineList
               console.log('cehckStatusrespons'+thi.$store.getters.getCuisineList);
          }
          }
          })
    }else{
        this.book_list=this.$store.getters.getCuisineList
    }
  },
  methods:{
    handleEdit(index, row) {
        console.log(index, row);
      },
      removetableDate: function (index) {
        console.log('manage index',index);
             let thi=this
             this.jquery.ajax({
               type:"post",
               crossDomain: true,
                xhrFields: {withCredentials: true},
               url:"http://127.0.0.1:8080/BookDinner-Server/sale/removeCuisine.action",
               async:true,
               headers: {
                  'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8'
               },
               dataType: "json",
               data:{
                 "id":this.book_list[index].id

               },
               success:function(date){
                  let th=thi
                 if(date.status=='-1'){

                 }else{
                   thi.$message({
                     type: 'success',
                     message: '成功删除'
                   });
                   thi.book_list.splice(index, 1);
                   thi.$store.commit('removeCuisine',index)


                 }
                 }
                 })
      },
      handleCurrentChange(val) {
            this.currentRow = val;
      },
      open2(item) {
        let thi=this
        this.$prompt('请重置菜系名', '修改', {
          confirmButtonText: '确定',
          cancelButtonText: '取消'
        }).then(({ value }) => {
          this.jquery.ajax({
            type:"post",
            crossDomain: true,
             xhrFields: {withCredentials: true},
            url:"http://127.0.0.1:8080/BookDinner-Server/sale/renameCuisine.action",
            async:true,
            headers: {
               'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8'
            },
            dataType: "json",
            data:{
              "id":item.id,
              'cuisine_name':value,
              'abs':item.abs,
              'img_url':item.imgUrl
            },
            success:function(date){
               let th=thi
              if(date.status=='-1'){

              }else{
                item.cuisineName=value
                thi.$store.commit('renameCuisine',item);
                thi.$message({
                  type: 'success',
                  message: '成功修改菜系名: ' + value
                });


              }
              }
              })
          console.log('then '+item.name);
        }).catch(() => {
          this.$message({
            type: 'info',
            message: '取消输入'
          });
        });
      },
      open3(){

        this.$router.push({path:"/Manager/CuisineManagementAdd"})
      }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
