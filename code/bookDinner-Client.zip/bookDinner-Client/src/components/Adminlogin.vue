<template>
<div class="login col-xs-12 ">

  <div class="panel panel-heading   col-xs-4 col-xs-push-4    login-box text-center">
    <h1 class="col-xs-12" style="color:#409EFF">{{ msg }}</h1>
    <div class="input-group login_input_username_div " id="login_input_username_div">
      <span class="input-group-addon"><i class="fa fa-user-o"></i></span>
      <input type="text" v-model='phone' name="login_username" class="form-control " id="login_input_username" :placeholder="placeholder_username">
    </div>
    <br>
    <div class="input-group login_input_password_div" id="login_input_password_div">
      <span class="input-group-addon"><i class="fa fa-key"></i></span>
      <input type="text" v-model='password' name="login_password" id="login_input_password" class="form-control" placeholder="密码">
    </div>

    <button  v-on:click="login()" type="button" class="col-xs-12 btn btn-default btn-group-vertical login-btn" name="button" style="color:#409EFF;"><i v-bind:class="{'fa fa-spinner fa-pulse':logins}"></i>登陆</button>
  </div>
</div>
</template>

<script>
import '../../static/css/login.css'
export default {
  name: 'login',
  data() {
    return {
      msg: '管理员登录',
      logins: false,
      phone:'',
      password:'',
      placeholder_username:'手机号'
    }
  },
  created: function() {
    let heigh

  },
  methods:{
    login(){
      let thi=this
      this.jquery.ajax({
        type:"post",
        crossDomain: true,
         xhrFields: {withCredentials: true},
        url:"http://127.0.0.1:8080/BookDinner-Server/adminLogin.action",
        async:true,
        headers: {
           'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8'
        },
        dataType: "json",
        data:{
          "type":1,
          "phone":this.phone,
          "password":this.password
        },
        success:function(date){
           let th=thi
          if(date.status=='-1'){
                  thi.$message('账号或密码错误');
          }else if(date.status=='0'){
               thi.$message('账号或密码错误');
          }else{
            console.log(date.results.passwrod);
              thi.$store.commit('updateUser', date.results)
              console.log('res'+thi.$store.getters.getUser.password);
              thi.$router.push({path:"/Manager/CuisineManagement"})
          }
            }
          })
    }
  }



}
</script>
<style media="screen">
.login {}

.login-box {

  padding-left: 15px;
  padding-right: 15px;
  padding-bottom: 10px;
  margin-top: 80px;
}
</style>

<!-- Add "scoped" attribute to limit CSS to this component only -->
