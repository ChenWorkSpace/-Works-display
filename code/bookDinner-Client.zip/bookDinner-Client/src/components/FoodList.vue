<template>
<div class="FoodList col-xs-12">
  <el-table
    ref="singleTable"
    :data="tableData"
    highlight-current-row
    @current-change="handleCurrentChange"
    style="width: 100%"
    align="center">
    <el-table-column
      property="name"
      label=""
      type="index"
      width="40px"
      align="center">
    </el-table-column>
    <el-table-column
      property="name"
      label="菜名"
      width="200px"
      align="center">
    </el-table-column>
    <el-table-column
      property="price"
      label="价格"
      width=" 100px"
      align="center">
    </el-table-column>
    <el-table-column
      property="sale"
      label="销量"
      width="100px"
      align="center">
    </el-table-column>
    <el-table-column
      property="im"
      label="预览图"
      width="300px"
      align="center"
      >
      <template slot-scope="scope">
        <img   v-lazy="scope.row.im" alt="" style="height:100px;width:100px">
      </template>
    </el-table-column>
    <el-table-column label="操作" align="center" width="300px">
      <template slot-scope="scope">
        <el-button
          size="mini"
          @click="open2">修改</el-button>
        <el-button
          size="mini"
          type="danger"
          @click="removetableDate(scope.$index)">删除</el-button>
      </template>
    </el-table-column>
    </el-table>
    <el-button round @click="open3">添加菜品</el-button>
</div>
</template>

<script>
export default {
  name: 'FoodList',
  data () {
    return {
      tableData: [{
        name: '',
        sale:'',
        im: ' ',
        price:'',
        jianjie: '',
        }],
        currentRow: null
    }
  },
  mounted:function(){
    this.tableData=[{
        name: '',
        sale:'',
        im: ' ',
        price:'',
        jianjie: '',
      }]
  },
  mounted:function(){
    this.tableData=this.$store.getters.getFoodList
  }
  ,
  methods:{
    handleEdit(index, row) {
        console.log(index, row);
      },
      removetableDate: function (index) {
        console.log('manage index',index);
             this.tableData.splice(index, 1);
      },
      handleCurrentChange(val) {
            this.currentRow = val;
      },
      open3() {
        this.$router.push({path:"/FoodListAdd"})
      },
      open2(){
        this.$router.push({path:"/FoodListManage"})
      }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
