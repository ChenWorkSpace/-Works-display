<template lang="html">
  <div>
    <el-button round @click="open3">返回主页</el-button>
  <el-table
    ref="singleTable"
    :data="tableData"
    highlight-current-row
    @current-change="handleCurrentChange"
    style="width: 100%"
    align="center">
    <el-table-column
      property="title"
      label=""
      width="300px"
      align="center">
    </el-table-column>
    <el-table-column
      property="input"
      lable=""
      width="300px"
      align="center"
      >
      <template slot-scope="scope">
        <el-input v-model="input" placeholder="请输入内容"></el-input>
      </template>
    </el-table-column>
  </el-table>
  <el-table
    ref="singleTable"
    :data="tableData2"
    highlight-current-row
    @current-change="handleCurrentChange"
    style="width: 100%"
    align="center">
    <el-table-column
      property="title"
      label=""
      width="300px"
      align="center">
    </el-table-column>
    <el-table-column
      property="iminput"
      lable=""
      width="300px"
      align="center"
      >
      <template slot-scope="scope">
        <input type="file" id="image" name="image" @change="preview($event)">
      </template>
    </el-table-column>
  </el-table>
  <el-button round v-on:click="add">确认添加</el-button>
</div>
</template>
<script>
export default {
  name: 'cookmanager',
  data () {
    return {
      tableData: [{
          title: '菜系名',
        }],
        tableData2: [{
            title: '选择预览图',
          }],
          input:'',
        currentRow: null
    }
  },
  methods: {
    preview(event){
      this.imgDataUrl = event.target.files;
    },
    open3(){
      this.$router.go(-1)
    },
    add(){
      let thi=this
      this.jquery.ajax({
        type:"post",
        crossDomain: true,
         xhrFields: {withCredentials: true},
        url:"http://127.0.0.1:8080/BookDinner-Server/sale/addCuisine.action",
        async:true,
        headers: {
           'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8'
        },
        dataType: "json",
        data:{
          "number":this.input
        },
        success:function(date){
           let th=thi
          if(date.status=='-1'){

          }else{
            thi.$store.commit('addCusineList',date.results)
            thi.$router.go(-1)
          }
          }
          })
    }
  }
}
</script>
