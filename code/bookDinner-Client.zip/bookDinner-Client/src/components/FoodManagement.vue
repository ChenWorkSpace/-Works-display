<template>

  <div class="row">

<div class="col-xs-2" style=" border-right: 1px solid #eee;">
    <div v-for="item in cuisine"  class="row" >
      <el-button class="col-xs-12 cuisineButton" v-on:click="CuisineClick(item)"  v-bind:class="actioned(item)">{{item.cuisineName}}</el-button>
    </div>
</div>
<div class="col-xs-10">
  <div class="FoodList col-xs-12">
    <el-table

      ref="singleTable"
      :data="tableData"
      highlight-current-row
      style="width: 100%"
      align="center">
      <el-table-column
        property="name"
        label=""
        type="index"
        width="40px"
        align="center">
      </el-table-column>
      <el-table-column
        property="foodName"
        label="菜名"
        width="200px"
        align="center">
      </el-table-column>
      <el-table-column
        property="price"
        label="价格"
        width=" 100px"
        align="center">
      </el-table-column>
      <el-table-column
        property="sale"
        label="销量"
        width="100px"
        align="center">
      </el-table-column>
      <el-table-column
        property="imgUrl"
        label="预览图"
        width="300px"
        align="center"
        >
        <template slot-scope="scope">
          <img   v-lazy="scope.row.imgUrl" alt="" style="height:100px;width:100px">
        </template>
      </el-table-column>
      <el-table-column label="操作" align="center" width="300px">
        <template slot-scope="scope">
          <el-button
            size="mini"
            @click="open2(scope.row)">修改</el-button>
          <el-button
            size="mini"
            type="danger"
            @click="removetableDate(scope.$index)">删除</el-button>
        </template>
      </el-table-column>
      </el-table>
      <el-button round @click="open3">添加菜品</el-button>
  </div>
</div>
  </div>

</template>

<script>
    export default {
        name: "cookviewa",
        data(){
          return {
             activeName:'0',
            currentId:"川菜",
            cuisine:[],
            tableData: [{
              name: '',
              sale:'',
              im: ' ',
              price:'',
              jianjie: '',
              }],
              currentRow: null
          }
        },
        computed:{

        },
        methods: {
          actioned:function(item){
            if(item.id==this.currentId){
              return "el-button el-button--primary"
            }else{
              return "el-button"
            }
          },
          CuisineClick:function(item){
            this.currentId=item.id;
            if(!this.$store.getters.getCuisineFood(this.currentId)){
              let thi=this
              this.jquery.ajax({
                type:"post",
                crossDomain: true,
                 xhrFields: {withCredentials: true},
                url:"http://127.0.0.1:8080/BookDinner-Server/sale/getFoodList.action",
                async:true,
                headers: {
                   'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8'
                },
                dataType: "json",
                data:{
                  'cuisine_id':this.currentId
                },
                success:function(date){
                   let th=thi
                   console.log('host_sale',date.status);
                   console.log('host_sale',date.results);
                  if(date.status=='-1'){

                  }else{

                    date['id']=thi.currentId
                    thi.$store.commit('updateCusineFood', date)

                    thi.tableData=thi.$store.getters.getCuisineFood(thi.currentId)


                  }
                  }
                })
              }
                    },
          handleEdit(index, row) {
              console.log(index, row);
            },
            removetableDate: function (index) {
               let thi=this
               console.log('manage index',index);
               this.jquery.ajax({
                 type:"post",
                 crossDomain: true,
                  xhrFields: {withCredentials: true},
                 url:"http://127.0.0.1:8080/BookDinner-Server/sale/delFood.action",
                 async:true,
                 headers: {
                    'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8'
                 },
                 dataType: "json",
                 data:{
                   "id":this.tableData[index].id
                 },
                 success:function(date){

                   if(date.status=='-1'){

                   }else{

                     thi.$store.commit('delFood',thi.tableData[index])
                     thi.tableData.splice(index,1)

                     thi.$message({
                       type: 'success',
                       message: '成功修改'
                     });


                   }
                   }
                   })

            },
            handleCurrentChange(val) {
                  this.currentRow = val;
            },
            open3() {
              this.$router.push({path:"/Manager/FoodListAdd"})
            },
            open2(item){
              this.$store.commit('updateCurrentChangeFood',item)
              this.$router.push({path:"/Manager/FoodListManage"})
            }
        },
        mounted:function(){
          let thi=this
            console.log('defaults');
            console.log(this.$store.getters.getCuisineList[0]);
              this.cuisine=this.$store.getters.getCuisineList
              if(!this.$store.getters.getCuisineFood(this.$store.getters.getCuisineList[0].id)){
                this.jquery.ajax({
                  type:"post",
                  crossDomain: true,
                   xhrFields: {withCredentials: true},
                  url:"http://127.0.0.1:8080/BookDinner-Server/sale/getFoodList.action",
                  async:true,
                  headers: {
                     'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8'
                  },
                  dataType: "json",
                  data:{
                    'cuisine_id':this.$store.getters.getCuisineList[0].id
                  },
                  success:function(date){

                     console.log('host_sale',date.status);
                     console.log('host_sale',date.results);
                    if(date.status=='-1'){

                    }else{
                      thi.currentId=thi.$store.getters.getCuisineList[0].id;
                      date['id']=thi.$store.getters.getCuisineList[0].id
                      thi.$store.commit('updateCusineFood', date)
                      console.log("dadad+"+thi.$store.getters.getCuisineList[0].id);
                      thi.tableData=thi.$store.getters.getCuisineFood(thi.$store.getters.getCuisineList[0].id)


                    }
                    }
                  })

              }
              else{
                console.log('default');
                  this.currentId=this.$store.getters.getCuisineList[0].id;
                this.tableData=this.$store.getters.getCuisineFood(this.$store.getters.getCuisineList[0].id)
              }


        }
    }
</script>
<style scoped>
.Cuisineactive{
  background-color: rgba(64,158,255,.1);
  display: inline-block;
  padding: 0 10px;
  height: 32px;
  line-height: 30px;
  font-size: 12px;
  color: #409eff;
  border-radius: 4px;
  box-sizing: border-box;
  border: 1px solid rgba(64,158,255,.2);
  white-space: nowrap;
}
.cuisineButton{
  height: 50px;
  border-color: #ffffff;
  border-bottom-color: #eeeee;

}
.h1{
  margin: 0;
}
</style>
