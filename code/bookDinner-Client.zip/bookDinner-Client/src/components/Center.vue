<template>
  <div class="col-xs-12">
    <div class="col-xs-12 header">
    </div>
    <div class="col-xs-12">


      <div class="head col-xs-12  col-xs-push-5" >

      </div>
    </div>

    <div class="col-xs-12">

      <h1 align='center' style="margin-top:20px;margin-bottom:40px;">{{user.username}}</h1>
    </div>

    <!-- <div class="col-xs-12">
        <div class="col-xs-3 col-lg-1 col-xs-push-1 col-lg-push-4">
          <lable class="lable">联系电话:</lable>
        </div>
        <div class="col-xs-3 col-lg-1 col-xs-push-1 col-lg-push-6">
          <p class="lable">联系电话:</p>
        </div>
    </div> -->
    <div class="col-xs-8 col-xs-push-2">
      <el-form ref="form" :model="form" label-width="300px" align="center">

        <el-form-item label="电话：" align="center">
         <p>{{user.phone}}</p>
        </el-form-item>
        <el-form-item label="送餐地址：" align="center">
      <p>{{user.addr}}</p>
        </el-form-item>


        <el-form-item label="即时配送">
          <el-switch v-model="form.delivery"></el-switch>
        </el-form-item>
        </el-form-item>
        <el-form-item label="支付">
          <el-radio-group v-model="form.resource">
            <el-radio label="货到付款"></el-radio>
            <el-radio label="在线支付"></el-radio>
          </el-radio-group>
        </el-form-item>
        <el-form-item label="备注">
           <p>不加辣，嘎嘎嘎</p>
        </el-form-item>

      </el-form>
    </div>

</div>
</template>

<script>
export default {
  name:'Centers',
    data() {
      return {
        user:{username:"",phone:"",addr:""},
        form: {

          name: '',
          region: '',
          date1: '',
          date2: '',
          delivery: false,
          type: [],
          resource: '',
          desc: ''
        }
      }
    },
    mounted:function(){
      console.log('Center'+this.$store.getters.getUser);
      this.user=this.$store.getters.getUser
    },
    methods: {
      onSubmit() {
        console.log('submit!');
      },
      clicks3:function(){
        this.$router.push({path:"/"})
      }
    }
  }

</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>

h1, h2 {
  font-weight: normal;
}
ul {
  list-style-type: none;
  padding: 0;
}
li {
  display: inline-block;
  margin: 0 10px;
}
a {
  color: #42b983;
}
.header{
background-size: cover;
  background-image: url(/static/img/pb_3.jpg);
  height: 200px;
}
.head{
  margin-top: -60px;
  height: 120px;
  width: 120px;
  /* border: solid 2px #aaaaaa; */
  margin-left: 60px;
  border-radius: 50%;
  background-size: cover;
  background-image: url(/static/img/default_head.jpg);
}



.lable{

float: left;
font-weight: 700;
font-size: 14px;
color: #606266;
line-height: 40px;
padding: 0 12px 0 0
}
</style>
