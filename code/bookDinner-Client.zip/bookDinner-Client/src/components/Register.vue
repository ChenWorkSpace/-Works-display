<template>
  <div class="col-lg-12" style="margin-top:120px;">
    <div class="col-xs-12 col-lg-4 col-lg-push-4">
      <h1 class="row register-title title" style="margin-bottom:20px;margin-left:50px;">{{msgs}}</h1>

<div class="row">
  <el-form :model="ruleForm2" status-icon :rules="rules2" ref="ruleForm2" label-width="100px" class="demo-ruleForm">
    <el-form-item label="用户名" prop="username">
      <el-input v-model="ruleForm2.username"></el-input>
    </el-form-item>
    <el-form-item label="年龄" prop="age" >
      <el-input v-model="ruleForm2.age"></el-input>
    </el-form-item>
    <el-form-item label="所在地" prop="addr" >
      <el-input v-model="ruleForm2.addr"></el-input>
    </el-form-item>
    <el-form-item label="手机号" prop="phone" >
      <el-input v-model="ruleForm2.phone"></el-input>
    </el-form-item>
    <el-form-item label="密码" prop="pass">
      <el-input type="password" v-model="ruleForm2.pass" auto-complete="off"></el-input>
    </el-form-item>
    <el-form-item label="确认密码" prop="checkPass">
      <el-input type="password" v-model="ruleForm2.checkPass" auto-complete="off"></el-input>
    </el-form-item>

    <el-form-item>
      <el-button type="primary" v-on:click="submitForm('ruleForm2')">确认注册</el-button>
      <el-button @click="resetForm('ruleForm2')">重置</el-button>
    </el-form-item>
  </el-form>
</div>

    </div>


</div>
</template>



<script>
  export default {
    name: 'Register',
    data() {
      var checkUsername = (rule, value, callback) => {
        if (!value) {
          return callback(new Error('用户名不能为空'));
        }else{
          callback();
        }
      }
      var checkPhone = (rule, value, callback) => {
        if (!value) {
          return callback(new Error('手机号不能为空'));
        }else{
          callback();
        }
      }
      var checkAge = (rule, value, callback) => {
        if (!value) {
          return callback(new Error('年龄不能为空'));
        }else{
          callback();
        }
      }
      var checkAddr = (rule, value, callback) => {
        if (!value) {
          return callback(new Error('地址不能为空'));
        }else{
          callback();
        }
      }
      var validatePass = (rule, value, callback) => {
        if (value === '') {
          callback(new Error('请输入密码'));
        } else {
          if (this.ruleForm2.checkPass !== '') {
            this.$refs.ruleForm2.validateField('checkPass');
          }
          callback();
        }
      }
      var validatePass2 = (rule, value, callback) => {
        if (value === '') {
          callback(new Error('请再次输入密码'));
        } else if (value !== this.ruleForm2.pass) {
          callback(new Error('两次输入密码不一致!'));
        } else {
          callback();
        }
      }
      return {
        msgs:"用户注册",
        ruleForm2: {
          pass: '',
          phone:'',
          checkPass: '',
          addr:'',
          age:'',
          username: ''
        },
        rules2: {
          pass: [
            { validator: validatePass, trigger: 'blur' }
          ],
          checkPass: [
            { validator: validatePass2, trigger: 'blur' }
          ],
          username: [
            { validator: checkUsername, trigger: 'blur' }
          ],
          phone: [
            { validator: checkPhone, trigger: 'blur' }
          ],
          age: [
            { validator: checkAge, trigger: 'blur' }
          ],
          addr: [
            { validator: checkAddr, trigger: 'blur' }
          ]

        }
      }
    },
    mounted:function(){
      console.log("Register","mounted");
    },
    methods: {
      submitForm:function(formName) {
        let thi=this
        this.$refs[formName].validate((valid) => {
            console.log('values'+valid);
          if (valid) {
            console.log('values'+valid);
            this.jquery.ajax({
              type:"post",
              crossDomain: true,
             xhrFields: {withCredentials: true},
              url:"http://127.0.0.1:8080/BookDinner-Server/register.action",
              async:true,
              headers: {
                 'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8'
              },
              dataType: "json",
              data:{
                 "username":this.ruleForm2.username,
                 'password':this.ruleForm2.pass,
                 'age':this.ruleForm2.age,
                 'phone':this.ruleForm2.phone,
                 'addr':this.ruleForm2.addr,
                 'type':0
              },
              success:function(date){
                if(date.status==0){
                   thi.$message('手机号已被使用');
                }else{
                  thi.$message('注册成功');
                  thi.$router.go(-1)
                }

              }
              })
          } else {
            console.log('error submit!!');
            return false;
          }
        });
      },
      resetForm:function(formName) {
        this.$refs[formName].resetFields();
      }
    }
  }
</script>

<style scoped>
.title{
  margin-bottom: 20px;
}
</style>
