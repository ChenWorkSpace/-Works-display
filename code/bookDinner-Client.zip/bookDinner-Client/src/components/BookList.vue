<template>

  <div class="row book-list router" >

    <div class="col-xs-12 col-lg-6">
      <el-card v-for="item in tab_list_left" :key="item.id" :body-style="{ padding: '0px' }" style="height:120px;margin-right:20px;margin-bottom:15px;">
          <!-- <img src="~examples/assets/images/hamburger.png" class="image"> -->
          <div v-lazy:background-image.container="item.imgUrl" class="img" style="height:120px;width:120px;float:left;"></div>
          <div style="padding: 10px;float:left;width:75%;" >
            <h3 style="font-size: 14px;font-weight: 700;margin:0px;float:left;" >{{item.foodName}}</h3>
            <div class="bottom clearfix" style="padding-top:10px;clear:both;height:60px;">
              <p style="color:#999;float:left;">{{item.abs}}</p>
            </div>

            <div class="" style="margin-left:4px;">
              <i class="fa fa-jpy" style="color:#f74342;float:left;"></i>
              <p style="margin-top:-4px;margin-left:4px;float:left;color:#f74342;font-size:16px;font-weight:700;">{{item.price}}</p>
              <p style="margin-top:-4px;margin-left:18px;float:left;font-size:14 px;font-weight:700;">销量:</p>
              <p style="margin-top:-4px;margin-left:4px;float:left;font-size:14 px;font-weight:700;" >{{item.sale}}</p>
              <p style="float:left;margin-top:-4px;margin-left:10px;">(天)</p>
                <el-button type="primary" style="float:right;margin-top:-10px;height:35px;width:100px;font-size:12px;" round>加入购物车</el-button>
            </div>
          </div>
        </el-card>
    </div>
    <div class="col-xs-12 col-lg-6" >


      <el-card v-for="item in tab_list_right" :key="item.id" :body-style="{ padding: '0px' }" style="height:120px;margin-left:20px;margin-bottom:15px">
          <!-- <img src="~examples/assets/images/hamburger.png" class="image"> -->
          <div v-lazy:background-image.container="item.imgUrl" class="img" style="height:120px;width:120px;float:left;"></div>
          <div style="padding: 10px;float:left;width:75%;" >
            <h3 style="font-size: 14px;font-weight: 700;margin:0px;float:left;" >{{item.foodName}}</h3>
            <div class="bottom clearfix" style="padding-top:10px;clear:both;height:60px;">
              <p style="color:#999;float:left;">{{item.abs}}</p>
            </div>

            <div class="" style="margin-left:4px;">
              <i class="fa fa-jpy" style="color:#f74342;float:left;"></i>
              <p style="margin-top:-4px;margin-left:4px;float:left;color:#f74342;font-size:16px;font-weight:700;">{{item.price}}</p>
              <p style="margin-top:-4px;margin-left:18px;float:left;font-size:14 px;font-weight:700;">销量:</p>
              <p style="margin-top:-4px;margin-left:4px;float:left;font-size:14 px;font-weight:700;" >{{item.sale}}</p>
              <p style="float:left;margin-top:-4px;margin-left:10px;">(天)</p>
                <el-button type="primary" style="float:right;margin-top:-10px;height:35px;width:100px;font-size:12px;" round>加入购物车</el-button>
            </div>
          </div>
        </el-card>
    </div>
  </div>
</template>




<script type="text/javascript">
export default {

  name: 'BookList',
  data () {
    return {
      input5: '',

      select: '',
      current:"1",
      trans:"sli-left",
      msg:"Manager",
      activeIndex2: '1',
      tab_list_left:[{}],
      tab_list_right:[{}]
    }
  },
  methods:{
    del:function(){
      console.log('destroy');
      this.$destroy();
    }
  },

  created:function(){
    console.log('booklist created');
  },
  mounted:function(){
    // let thi=this
    // if(!this.$store.getters.getCuisineFood(this.$store.getters.getSelectedCusineFoodId)){
    //   let thi=this
    //   this.jquery.ajax({
    //     type:"post",
    //     crossDomain: true,
    //      xhrFields: {withCredentials: true},
    //     url:"http://127.0.0.1:8080/BookDinner-Server/sale/getFoodList.action",
    //     async:true,
    //     headers: {
    //        'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8'
    //     },
    //     dataType: "json",
    //     data:{
    //       'cuisine_id':this.$store.getters.getCuisineList[0].id
    //     },
    //     success:function(date){
    //        let th=thi
    //        console.log('host_sale',date.status);
    //        console.log('host_sale',date.results);
    //       if(date.status=='-1'){
    //
    //       }else{
    //           date['id']=thi.$store.getters.getCuisineList[0].id
    //           thi.$store.commit('updateCusineFood', date)
    //       }
    //       }
    //       })
    // }
    console.log(this.$store.getters.getCuisineFood(this.$store.getters.getSelectedCusineFoodId));
    console.log("BookListLeftRight");
    this.tab_list_left=this.$store.getters.getCuisineFoodLeft
    this.tab_list_right=this.$store.getters.getCuisineFoodRight
   console.log('tab_list_left-length'+ this.tab_list_left.length);
    console.log(this.tab_list_left);

    // this.$store.watch(
    //   (state)=>state.book_del,(val)=>{
    //       console.log('destroys'+val)
    //       console.log(this.tab_list_left);
    //       if(val==true){
    //         this.tab_list_left=[]
    //         this.tab_list_right=[]
    //         this.$store.commit('updateBookDel', false)
    //         console.log(this.tab_list_left);
    //         this.$destroy()
    //       }
    //
    //   },{
    //     deep:true
    //   }
    // )

  }

}
</script>
<style scoped="">
.img{

 background-size: cover;
}
</style>
