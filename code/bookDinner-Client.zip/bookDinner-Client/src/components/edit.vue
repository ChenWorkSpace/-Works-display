<template>
   <div>
   <el-table
     :data="tableData"
     style="width: 100%">
     <el-table-column
       prop="title"
       label=""
       width="180">
     </el-table-column>
     <el-table-column
       prop="input"
       label=""
       width="180">
     </el-table-column>
     <el-table-column  width="200px">
       <template slot-scope="scope">
         <el-input v-model="input" placeholder="请输入内容"></el-input>
      </template>
     </el-table-column>
   </el-table>
     <el-button type="primary">提交</el-button>
   </div>
 </template>



<script>
export default {
     data() {
       return {
         tableData: [{
           title: '用户名：',


         }, {
           title: '密码：',


         }, {
           title: '地址：',


         }]
       }
     }
   }

</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>

h1, h2 {
  font-weight: normal;
}
ul {
  list-style-type: none;
  padding: 0;
}
li {
  display: inline-block;
  margin: 0 10px;
}
a {
  color: #42b983;
}
</style>
