<template>
<div class="hello col-xs-12">
  <el-table
    ref="singleTable"
    :data="tableData"
    highlight-current-row
    @current-change="handleCurrentChange"
    style="width: 100%"
    align="center">
    <el-table-column
      type="index"
      width="200px">
    </el-table-column>
    <el-table-column
      property="name"
      label="菜名"
      width="300px">
    </el-table-column>
    <el-table-column
      property="im"
      label="预览图"
      width="300px"
      >
      <template slot-scope="scope">
        <img :src="scope.row.im" alt="" style="height:100px;width:100px">
      </template>
    </el-table-column>
    <el-table-column align="center">
      <template slot-scope="scope">
        <el-button
          size="mini"
          @click="handleEdit(scope.$index, scope.row)">选择菜品</el-button>
      </template>
    </el-table-column>
    </el-table>
</div>
</template>

<script>
export default {
  name: 'cookview',
  data () {
    return {
      tableData: [{
          name: '川菜',
          im: ' /static/s1.jpg',
        }, {
            name: '鲁菜',
            im: ' /static/s2.jpg',
        }, {
          name: '粤菜',
          im: ' /static/s3.jpg',
        }, {
          name: '苏菜',
          im: ' /static/s4.jpg',
        },{
          name: '浙菜',
          im: ' /static/s5.jpg',
        },{
          name: '闽菜',
          im: ' /static/s6.jpg',
        },{
          name: '湘菜',
          im: ' /static/s7.jpg',
        },{
          name: '徽菜',
          im: ' /static/s8.jpg',
        }],
        currentRow: null
    }
  },
  methods:{
    handleEdit(index,row){
      this.$router.push({path:"/cookviewa"})
    },
   handleCurrentChange(val) {
     this.currentRow = val;
   }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
