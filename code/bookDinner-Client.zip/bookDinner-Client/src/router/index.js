﻿import Vue from 'vue'
import Router from 'vue-router'
import HelloWorld from '@/components/HelloWorld'
import Login from '@/components/Login'
import home from '@/components/home'
import Manager from '@/components/Manager'
import Adminlogin from '@/components/Adminlogin'
import FoodManagement from '@/components/FoodManagement'
import CuisineManagement from '@/components/CuisineManagement'
import FoodList from '@/components/FoodList'
import FoodListManage from '@/components/FoodListManage'
import FoodListAdd from '@/components/FoodListAdd'
import OrderManagement from '@/components/OrderManagement'
import OrderDetails from '@/components/OrderDetails'
import UserManager from '@/components/UserManager'
import HeadPage from '@/components/HeadPage'
import BookList from '@/components/BookList'
import UserOrderConfirm from '@/components/UserOrderConfirm'
import UserOrderDetails from '@/components/UserOrderDetails'
import Register from '@/components/Register'
import User from '@/components/User'
import Center from '@/components/Center'
import UserOrderManagement from '@/components/UserOrderManagement'
import CuisineManagementAdd from '@/components/CuisineManagementAdd'

Vue.use(Router)

export default new Router({
  mode: 'history',
  routes: [
  {
    path: '/UserManager/HeadPage/BookList',
    component: BookList,
    alias: 'UserManager/HeadPage/:id'
  },
  {
    path: '/Manager/OrderDetails' ,
    component: OrderDetails,
    alias: '/Manager/OrderManagement/OrderDetails'
  },
    {
      path: '/',
      name: 'HelloWorld',
      component: HelloWorld
    },
    {
      path:'/Login',
      name:'Login',
      component:Login
    },
    {
      path:'/Register',
      name:'Register',
      component:Register
    },
    {
      path:"/Manager",
      name:"Manager",
      component:Manager,
      meta:{requiresAuth:true},
      children:[
        {  path:'/Manager/CuisineManagement',
           name:'Management',
           component:CuisineManagement},
          
           {  path:'/Manager/FoodListAdd',
              name:'FoodListAdd',
              component:FoodListAdd},
           {  path:'/Manager/FoodListManage',
              name:'FoodListManage',
              component:FoodListManage},
           {  path:'/Manager/CuisineManagementAdd',
              name:'CuisineManagementAdd',
              component:CuisineManagementAdd},
        {  path:'/Manager/FoodManagement',
           name:'cookmanager',
           component:FoodManagement,
         children:[
           {path:'/Manager/FoodManagement/FoodList',
           name:'FoodList',
           component:FoodList}
         ]},
        {  path:'/Manager/OrderManagement',
           name:'OrderManagement',
           component:OrderManagement
        },
          {path:'/Manager/OrderManagement/OrderDetails',
          name:'OrderDetails',
          component:OrderDetails}
      ]
      },
      {
        path:"/UserManager" ,
        name:'UserManager',
        component:UserManager,
        children:[
          {path:'/UserManager/HeadPage' ,
          name:'HeadPage',
          component:HeadPage,
        children:[
          {path:'/UserManager/HeadPage/:id',
          name:'BookList',
          component:BookList}
        ]},
        {path:'/UserManager/UserOrderConfirm', name:'UserOrderConfir',component:UserOrderConfirm},
        {path:'/UserManager/Center' ,
        name:'Center',
        component:Center},
        {path:'/UserManager/UserOrderManagement' ,
        name:'UserOrderManagement',
        component:UserOrderManagement},
        {path:'/UserManager/UserOrderManagement/UserOrderDetails' ,
        name:'UserOrderDetails',
        component:UserOrderDetails},
        {path:'/UserManager/UserOrderManagement/UserOrderConfirm',
        name:'UserOrderConfirm',
        component:UserOrderConfirm}
        ]
      },

    {
      path:'/Adminlogin',
      name:'Adminlogin',
      component:Adminlogin
    }

  ]
})
