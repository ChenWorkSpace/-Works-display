<template>
  <div id="app" class="container-fluid root" >
    <div class="row">
      <transition :name="transitionName">
          <keep-alive>
      <router-view class="Router"></router-view>
          </keep-alive>
      </transition>
    </div>

  </div>
</template>

<script>
export default {
  name: 'app',
  data(){
    return {
      parent:"parent",
        transitionName: 'parent'
    }
  },
  watch: {
    '$route' (to, from) {
    let toDepth = 0;

    if(to.name=="HelloWorld"){
      toDepth=0;
    }else{
      toDepth=1;
    }
    console.log(toDepth)
    this.transitionName = toDepth == 0   ? 'slide-right' : 'slide-left'
   console.log("transitionName: "+this.transitionName);
    }
  },
  mounted:function(){

  }
}
</script>

<style>
#app {
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
}

.root{
  padding-left: 0px;
  padding-right: 0px;
}
.row {
  margin: 0;
}

.col-lg-1,
.col-lg-10,
.col-lg-11,
.col-lg-12,
.col-lg-2,
.col-lg-3,
.col-lg-4,
.col-lg-5,
.col-lg-6,
.col-lg-7,
.col-lg-8,
.col-lg-9,
.col-md-1,
.col-md-10,
.col-md-11,
.col-md-12,
.col-md-2,
.col-md-3,
.col-md-4,
.col-md-5,
.col-md-6,
.col-md-7,
.col-md-8,
.col-md-9,
.col-sm-1,
.col-sm-10,
.col-sm-11,
.col-sm-12,
.col-sm-2,
.col-sm-3,
.col-sm-4,
.col-sm-5,
.col-sm-6,
.col-sm-7,
.col-sm-8,
.col-sm-9,
.col-xs-1,
.col-xs-10,
.col-xs-11,
.col-xs-12,
.col-xs-2,
.col-xs-3,
.col-xs-4,
.col-xs-5,
.col-xs-6,
.col-xs-7,
.col-xs-8,
.col-xs-9 {
  padding: 0;
}

.Router {
     position: absolute;
     width: 100%;
     transition: all .35s ;

}
.slide-left-enter,
 .slide-right-leave-active {

    -webkit-transform: translate(100%, 0);
    transform: translate(100%, 0);
}

.slide-left-leave-active,
.slide-right-enter {

    -webkit-transform: translate(-100%, 0);
    transform: translate(-100%, 0);
}



</style>
