// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
import $ from 'jquery'
import 'jquery'
import './assets/jquery/jquery-3.1.1.min'
import './assets/bootstrap/css/bootstrap.min.css'
import './assets/bootstrap/js/bootstrap.min'
import './assets/font-awesome/css/font-awesome.css'
import Vue from 'vue'
import App from './App'
import login from '../static/js/login'
import util from '../static/js/util'
import store from '../static/js/store'
import axios from 'axios'
import router from './router'
import ElementUI from "element-ui"
import 'element-ui/lib/theme-chalk/index.css'
import VueLazyLoad from 'vue-lazyload'
Vue.config.productionTip = false
Vue.prototype.axios=axios
Vue.prototype.Host='/api'
Vue.prototype.jquery=$
Vue.use(login)
Vue.use(VueLazyLoad,{
  preLoad: 1.3,
  error: 'dist/error.png',
  loading: 'dist/loading.gif',
  attempt: 1
})
Vue.use(ElementUI)
/* eslint-disable no-new */

if (module.hot) {
  module.hot.accept();
}
new Vue({
  el: '#app',
  router,
  store,
  template: '<App/>',
  components: { App }
})
