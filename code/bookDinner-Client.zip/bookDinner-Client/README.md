# bookDinner

> A Vue.js project

## Build Setup
### 依赖安装过程中可能会出现:```Unexpected end of JSON input while parsing near '...```这样的错误，解决方法如下：
输入:```npm cache clean --force```
``` bash
# install dependencies
npm install

# serve with hot reload at localhost:8080
npm run dev

# build for production with minification
npm run build

# build for production and view the bundle analyzer report
npm run build --report

# run unit tests
npm run unit

# run e2e tests
npm run e2e

# run all tests
npm test
```
xxxxxx

For a detailed explanation on how things work, check out the [guide](http://vuejs-templates.github.io/webpack/) and [docs for vue-loader](http://vuejs.github.io/vue-loader).
=======
bookDinner
>>>>>>> bbfa78f707ea8e19cb68fdb402fd59b548add239
