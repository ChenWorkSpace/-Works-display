import Vue from 'vue'
import Vuex from 'vuex'
Vue.use(Vuex)

export default new Vuex.Store({
  state: {
    userState: 0,
    userName: null,
    userId: null,
    book_del:false,
    user:null,
    cuisine_list:null,
    hot_sale:null,
    hot_sale_left:[],
    hot_sale_right:[],
    cuisine_food_left:[],
    cuisine_food_right:[],
    cuisine_food:null,
    selected_cuisine_food_id:1,
    settlement_item:null,
    settlement_list:[],
    current_change_food:""

  },
  getters: {
    getCurrentChangeFood:state=>{
      if (!state.current_change_food && sessionStorage.current_change_food) {
        state.current_change_food = JSON.parse(sessionStorage.current_change_food)
      }
      return state.current_change_food
    },

    getSettlementList:state=>{
      if (!state.settlement_list && sessionStorage.settlement_list) {
        state.settlement_list = JSON.parse(sessionStorage.settlement_list)
      }
      return state.settlement_list
    },
    clearSettlementList:state=>{
       state.settlement_list=[]
       sessionStorage.setItem('settlement_list', JSON.stringify(state.settlement_list))
    },
    getSettlementItem:state=>{
      if (!state.settlement_item && sessionStorage.settlement_item) {
        state.settlement_item = JSON.parse(sessionStorage.settlement_item)
      }
      return state.settlement_item
    },
    getCuisineFoodLeft:state=>{
      if (!state.cuisine_food_left && sessionStorage.cuisine_food_left) {
        state.cuisine_food_left = JSON.parse(sessionStorage.cuisine_food_left)
      }
      return state.cuisine_food_left
    },
    getCuisineFoodRight:state=>{
      if (!state.cuisine_food_right && sessionStorage.cuisine_food_right) {
        state.cuisine_food_right = JSON.parse(sessionStorage.cuisine_food_right)
      }
      return state.cuisine_food_right
    },
    getSelectedCusineFoodId:state=>{
      if (!state.selected_cuisine_food_id && sessionStorage.selected_cuisine_food_id) {
        state.selected_cuisine_food_id = JSON.parse(sessionStorage.selected_cuisine_food_id)
      }
      console.log('getSelectedCusineFoodId'+state.selected_cuisine_food_id);
      return state.selected_cuisine_food_id
    },
    getCuisineFood:(state,getters) => (id) => {
      if(this.cuisine_food==null && sessionStorage.cuisine_food){
        state.cuisine_food=JSON.parse(sessionStorage.cuisine_food)
      }
      console.log('id'+id);
      if(state.cuisine_food!=null){
        console.log('cuisineFoodReturnLenght'+state.cuisine_food[1]);
        return state.cuisine_food[id]

      }else{
        return null
      }
    },
    getListLeft:(state,getters) => (list,left,sessionName) => {
      left=[]
        let s=0
        if(list){
          for(let i=0;i<list.length;i++){
            if(i%2==0){
                left[s]=list[i]
              s++
            }
          }
          console.log('sessionNameL'+sessionName);
        sessionStorage.setItem(sessionName, JSON.stringify(left))
        }

      return left
    },
    getListRight:(state,getters) => (list,right,sessionName) => {
      right=[]
      let s=0
      if(list){
        for(let i=0;i<list.length;i++){
          if(i%2!=0){
              right[s]=list[i]
            s++
          }
        }
        console.log('sessionNameR'+sessionName);
      sessionStorage.setItem(sessionName, JSON.stringify(right))
      }

    return right
    },
    getHotSale:state=>{
      if (!state.hot_sale && sessionStorage.hot_sale) {
        state.hot_sale = JSON.parse(sessionStorage.hot_sale)
      }
      return state.hot_sale
    },
    getCuisineList:state=>{
      if (!state.cuisine_list && sessionStorage.cuisine_list) {
        state.cuisine_list = JSON.parse(sessionStorage.cuisine_list)
      }
      return state.cuisine_list
    },
    getUser:state=>{
      if (!state.user && sessionStorage.user) {
        state.user = JSON.parse(sessionStorage.user)
      }
      return state.user
    },
   getBookDel:state=>{
       return state.book_del
   }

  },
  mutations: {
    delFood(state,food){
      if(this.cuisine_food==null && sessionStorage.cuisine_food){
        state.cuisine_food=JSON.parse(sessionStorage.cuisine_food)
      }
      if(state.cuisine_food){
        if(state.cuisine_food[food.cuisineId]){
          console.log('begin........'+state.cuisine_food[food.cuisineId].length);
          console.log('begin........'+food.id);
          for(let i=0;i<state.cuisine_food[food.cuisineId].length;i++){
              console.log('target........'+state.cuisine_food[food.cuisineId][i].id);
            if(state.cuisine_food[food.cuisineId][i].id==food.id){
                 console.log('targeed');
              state.cuisine_food[food.cuisineId].splice(i,1)
              sessionStorage.setItem('cuisine_food', JSON.stringify(state.cuisine_food))
            }
          }


        }
      }
    },
    addFood(state ,food){
      if(this.cuisine_food==null && sessionStorage.cuisine_food){
        state.cuisine_food=JSON.parse(sessionStorage.cuisine_food)
      }
      if(state.cuisine_food){
        if(state.cuisine_food[food.cuisineId]){
          state.cuisine_food[food.cuisineId].unshift(food)
          sessionStorage.setItem('cuisine_food', JSON.stringify(state.cuisine_food))

        }
      }
    },

    saveCurrentChangeFood(state,food){
      if(this.cuisine_food==null && sessionStorage.cuisine_food){
        state.cuisine_food=JSON.parse(sessionStorage.cuisine_food)
      }
      if(state.cuisine_food){
         console.log('start)1');
          console.log(state.cuisine_food[1]);
        if(state.cuisine_food[food.cuisineId]){
             console.log('start');
          for(let j=0;j<state.cuisine_food[food.cuisineId].length;j++){
             if(food.id==state.cuisine_food[food.cuisineId][j].id){
               console.log(state.cuisine_food[food.cuisineId][j].foodName);
               state.cuisine_food[food.cuisineId][j]=food
               sessionStorage.setItem('cuisine_food', JSON.stringify(state.cuisine_food))
             }
          }
        }
      }


    },
    updateCurrentChangeFood(state,id){
      state.current_change_food=id
      sessionStorage.setItem('current_change_food', JSON.stringify(state.current_change_food))
    },
    updateSettlementListTrail(state,item){

      state.settlement_list.push(item)
      sessionStorage.setItem('settlement_list', JSON.stringify(state.settlement_list))
    },
    updateSettlementListHead(){
      state.settlement_list.unshift(item)
      sessionStorage.setItem('settlement_list', JSON.stringify(state.settlement_list))
    },
    updateSettlementItem(state,item){
      state.settlement_item=item
      sessionStorage.setItem('settlement_item', JSON.stringify(state.settlement_item))
    },
   updateSelectedCusineFoodId(state,id){
         state.selected_cuisine_food_id=id
         sessionStorage.setItem('selected_cuisine_food_id', JSON.stringify(state.selected_cuisine_food_id))
    },
   updateCusineFood(state,data){
     if(!state.cuisine_food){
       state.cuisine_food={}
     }
     state.cuisine_food[data['id']]=data['results']
     sessionStorage.setItem('cuisine_food', JSON.stringify(state.cuisine_food))
   },

    updateHotSale(state,data){
      console.log('updateHotSale');
      sessionStorage.setItem('hot_sale', JSON.stringify(data))
      state.hot_sale=data
    },
    updateUser(state,user){
      if(user==null){
          sessionStorage.setItem('user', null)
          state.user=null
      }
      sessionStorage.setItem('user', JSON.stringify(user))
      state.user=user
    },
    addCusineList(state,item){
      if(!state.cuisine_list){
           state.cuisine_list = JSON.parse(sessionStorage.cuisine_list)
      }
      state.cuisine_list.unshift(item)
        sessionStorage.setItem('cuisine_list', JSON.stringify(state.cuisine_list))
    },
    renameCuisine(state,item){
      if(!state.cuisine_list){
           state.cuisine_list = JSON.parse(sessionStorage.cuisine_list)
      }
      for(let i=0;i<state.cuisine_list.length;i++){
        if(state.cuisine_list[i].cuisineName==item.cuisineName){
          state.cuisine_list[i]=item
          sessionStorage.setItem('cuisine_list', JSON.stringify(state.cuisine_list))
        }
      }
    },
    removeCuisine(state,index){
      if(!state.cuisine_list){
           state.cuisine_list = JSON.parse(sessionStorage.cuisine_list)
      }
      state.cuisine_list.splice(index, 1);
      sessionStorage.setItem('cuisine_list', JSON.stringify(state.cuisine_list))
    },
    updateCuisineList(state,list){
      sessionStorage.setItem('cuisine_list', JSON.stringify(list))
      state.cuisine_list=list
    },
    updateBookDel(state,State){
      state.book_del=State;
    }

  },
  actions: {},
  modules: {}
})
